#!/system/bin/sh
# Trampoline only. All module logic lives in a16fixd (NDK-built native core).
# Some managers extract ZIP entries as 0644 or mount /data/adb noexec, so the
# exec bit is restored here and, if needed, the core is copied to /data/local/tmp.
# If native still cannot run, sha256sum reports changed files. Never break install.
# Copyright (c) 2026 @FebriCahyaa. All rights reserved.
D=${MODPATH:-${MODDIR:-${0%/*}}}
[ -d "$D/bin" ] || D=$(pwd)
A=$(getprop ro.product.cpu.abi 2>/dev/null)
echo "customize.sh reached D=$D A=$A" > /data/local/tmp/a16fix_install_trace 2>/dev/null
ls -l "$D/bin/$A/" >> /data/local/tmp/a16fix_install_trace 2>/dev/null
if [ ! -x "$D/bin/$A/a16fixd" ]; then
    for p in "$D"/bin/*/a16fixd; do
        [ -f "$p" ] || continue
        A=${p#*/bin/}
        A=${A%/a16fixd}
        break
    done
fi
B="$D/bin/$A/a16fixd"
if [ -f "$B" ] && [ ! -x "$B" ]; then
    chmod 0755 "$B" "$D/bin/$A/a16fixctl" 2>/dev/null
    echo "chmod restored for $B" >> /data/local/tmp/a16fix_install_trace 2>/dev/null
fi
if [ -f "$B" ] && [ ! -x "$B" ]; then
    T="/data/local/tmp/a16fix_$A"
    cp "$B" "$T" 2>/dev/null && chmod 0755 "$T" 2>/dev/null && B="$T"
    echo "copied core to $B" >> /data/local/tmp/a16fix_install_trace 2>/dev/null
fi
if [ -x "$B" ]; then
    "$B" installer "$D"
    rc=$?
    echo "native installer rc=$rc (B=$B)" >> /data/local/tmp/a16fix_install_trace 2>/dev/null
    if [ "$rc" -eq 0 ]; then
        exit 0
    fi
    echo "a16_data_fix: native installer returned $rc, using shell fallback"
else
    echo "a16_data_fix: native core not found at $D/bin/$A/a16fixd"
fi
echo "- File integrity check (SHA256) [shell fallback]:"
if [ -f "$D/security/sha256.manifest" ] && command -v sha256sum >/dev/null 2>&1; then
    (cd "$D" && sha256sum -c security/sha256.manifest 2>&1) | grep -v ': OK$' || true
else
    echo "  manifest or sha256sum unavailable; boot-time native check still applies"
fi
echo "a16_data_fix: installation continues; custom patches stay off by default"
exit 0
