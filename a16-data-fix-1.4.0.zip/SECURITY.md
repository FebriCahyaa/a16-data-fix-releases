# a16_data_fix security model

## 1. SHA256 integrity (real)

`build.sh` generates `security/sha256.manifest` containing the SHA256 hash of
every shipped file, including all native binaries and the Zygisk `.so`.

During `post_fs_data`, the native core (`liba16fix_core.so`):

1. hashes every manifest entry with `sha256_file()` from `liba16fix_crypto.so`,
2. records the engine as `native_sha256` in `state.env` and in the report,
3. rejects all custom dynamic modules when any entry is missing or changed.

- Match -> custom modules may load.
- Mismatch -> all `USE_CUSTOM_PATCH_*` are forced off and an error is logged.
- `REQUIRE_SHA256=0` skips verification during normal boot stages and logs that
  fact. The `installer` and `verify` stages always verify, regardless of config.

Because verification itself is native, a broken `sha256sum` on the device does
not weaken the check. The crypto module also runs a known-answer self-test for
SHA256 ("abc") at startup; a failure marks the engine as
`sha256_selftest_failed` and rejects every patch.

### Install-time and on-demand file identification

- `customize.sh` runs `a16fixd installer` first. It prints the exact path,
  expected hash and actual hash of every `CHANGED` or `MISSING` file, plus any
  `UNLISTED` file. Reporting is non-fatal by design: root managers may rewrite
  module files while extracting. Custom patches are still rejected because the
  boot stages gate them on the recorded `fail` status.
- `verify.sh` runs `a16fixd verify` at any time. Output format:

```
CHANGED  lib/arm64-v8a/liba16fix_core.so
         expected <sha256 from manifest>
         actual   <sha256 computed on device>
MISSING  module.prop
         expected <sha256 from manifest>
UNLISTED lib/arm64-v8a/liba16fix_custom_data.so.enc
```

`a16fixctl verify <manifest> <root>` provides the same detail as a standalone
native helper. `UNLISTED` is informational: user-supplied custom patches and
manager markers (`disable`, `skip_mount`, `sepolicy.rule`, `zygisk/unloaded`) are
not treated as tampering.

## 2. Encrypted payloads (real, with a caveat)

`a16fixctl encrypt/decrypt` and `liba16fix_crypto.so` use **AES-256-CBC +
HMAC-SHA256** (encrypt-then-MAC), not XOR or obfuscation:

```
"A16FIX01" | IV(16) | ciphertext(PKCS#7) | HMAC-SHA256(32)
```

The HMAC is verified with `constant_time_eq()` before decryption. A modified
payload or a wrong keyfile is rejected.

The AES + HMAC keys are generated as Secrets in the **private source
repository** and are only used when building encrypted modules. The keyfile is
**not** shipped in the ZIP. The device owner installs it at:

```
/data/adb/a16_data_fix/keys/payload.key   # 128 hex digits, chmod 0600
```

then sets `USE_NATIVE_CRYPTO=1`. With that flag, the core decrypts
`lib/<abi>/liba16fix_custom_<slot>.so.enc` into the runtime directory and
loads it only after the HMAC check passes.

**Honest limitation:** the decryption routine is present in the shipped
source and binaries. Someone with the ZIP can still extract the algorithm;
the keyfile kept on the device is what actually gates execution. This raises
the effort required to tamper, but it is not absolute protection. Real
protection requires a key outside the device (server/HSM).

The old `*.b64` byte-shift obfuscation mode has been removed. It was never
encryption and should not be described as such.

## 3. No metamodule=1

`metamodule=1` is deliberately **omitted**. KernelSU accepts only one active
metamodule and a metamodule must provide `metamount.sh`. Marking this module as
one would break mounting for every other module.

## 4. sepolicy

`sepolicy.rule.example` is inactive by default. A SELinux rule with a domain
that does not exist on a given build can make `magiskpolicy` fail during
pre-init. Enable it only through `/data/adb/a16_data_fix/sepolicy.optin` after
checking `su -c 'id -Z'`.

## 5. Zygisk

The Zygisk module is intentionally inert: no hooks, no application data
access. This reduces bootloop and misuse risk. The companion only answers a
ping.

## 6. Copyright

See `COPYRIGHT`. (c) 2026 @FebriCahyaa. All rights reserved.
