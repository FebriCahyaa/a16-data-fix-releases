#!/system/bin/sh
# Trampoline only. All logic lives in a16fixd (NDK-built native core).
# Copyright (c) 2026 @FebriCahyaa. All rights reserved.
D=${MODPATH:-${MODDIR:-${0%/*}}}
[ -d "$D/bin" ] || D=$(pwd)
A=$(getprop ro.product.cpu.abi 2>/dev/null)
if [ ! -x "$D/bin/$A/a16fixd" ]; then
    for p in "$D"/bin/*/a16fixd; do
        [ -f "$p" ] || continue
        A=${p#*/bin/}
        A=${A%/a16fixd}
        break
    done
fi
B="$D/bin/$A/a16fixd"
if [ -f "$B" ] && [ ! -x "$B" ]; then chmod 0755 "$B" "$D/bin/$A/a16fixctl" 2>/dev/null; fi
if [ -f "$B" ] && [ ! -x "$B" ]; then
    T="/data/local/tmp/a16fix_$A"
    cp "$B" "$T" 2>/dev/null && chmod 0755 "$T" 2>/dev/null && B="$T"
fi
[ -x "$B" ] || exit 1
exec "$B" verify "$D"
