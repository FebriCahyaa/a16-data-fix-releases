'use strict';

const byId = (id) => document.getElementById(id);

function text(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback || '-';
  return String(value);
}

function escapeHtml(value) {
  return text(value, '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[c]);
}

function row(label, value) {
  return '<div class="row"><dt>' + escapeHtml(label) + '</dt><dd>' +
         escapeHtml(value) + '</dd></div>';
}

function status(data) {
  if (data.integrity && data.integrity !== 'ok' && data.integrity !== 'skipped') {
    return ['bad', 'Integrity ' + data.integrity];
  }
  const failed = Number(data.failed || 0);
  const created = Number(data.created || 0);
  if (failed > 0) return ['warn', failed + ' folder' + (failed === 1 ? '' : 's') + ' failed'];
  if (created > 0) return ['good', 'Repaired ' + created + ' folder' + (created === 1 ? '' : 's')];
  return ['good', 'No missing folders'];
}

function renderReport(data) {
  byId('moduleName').textContent = text(data.module, 'QPR Storage Fix');
  byId('versionChip').textContent = 'v' + text(data.version, '--');
  byId('scanTime').textContent = text(data.generated, '-');
  byId('scanStage').textContent = data.stage
    ? 'Stage: ' + data.stage + ' | updated from the module scan'
    : 'No data yet. Reboot or press Action.';

  const [tone, label] = status(data);
  const pill = byId('statusPill');
  pill.className = 'status-pill ' + tone;
  pill.textContent = label;

  byId('statPackages').textContent = text(data.packages, '-');
  byId('statCreated').textContent = text(data.created, '-');
  byId('statFailed').textContent = text(data.failed, '-');

  byId('androidDetails').innerHTML =
    row('Release', text(data.android_release, 'unknown')) +
    row('SDK', text(data.android_sdk, 'unknown')) +
    row('Codename', text(data.android_codename, 'unknown')) +
    row('Build ID', text(data.android_build_id, 'unknown')) +
    row('Preview SDK', text(data.android_preview_sdk, '0')) +
    row('QPR', text(data.qpr, 'unknown')) +
    row('Detail', text(data.qpr_detail, 'unknown'));

  byId('storageDetails').innerHTML =
    row('Type', text(data.storage_type, 'unknown')) +
    row('Source', text(data.storage_source, 'unknown')) +
    row('Options', text(data.storage_options, 'unknown'));

  byId('zygiskDetails').innerHTML =
    row('Status', text(data.zygisk_status, 'unknown')) +
    row('Implementation', text(data.zygisk_impl, 'none')) +
    row('Version', text(data.zygisk_version, 'unknown')) +
    row('API', text(data.zygisk_api, 'unknown'));

  byId('safetyDetails').innerHTML =
    row('Root', text(data.root, 'unknown') + ' ' + text(data.root_version, '')) +
    row('Metamodule', data.metamodule_active ? 'active | ' + text(data.metamodule_id, 'unknown') : 'none') +
    row('Integrity', text(data.integrity, 'unknown')) +
    row('Engine', text(data.integrity_engine, 'none'));

  byId('rawJson').textContent = JSON.stringify(data, null, 2);
}

function renderHistory(raw) {
  const body = byId('historyBody');
  const lines = raw.split('\n').filter((line) => line.trim() !== '');
  if (lines.length === 0) {
    body.innerHTML = '<tr><td colspan="7" class="muted">No runs recorded yet.</td></tr>';
    return;
  }

  const entries = [];
  for (const line of lines) {
    try { entries.push(JSON.parse(line)); } catch (ignored) { /* keep the table readable */ }
  }
  entries.reverse();

  body.innerHTML = entries.slice(0, 20).map((e) =>
    '<tr>' +
      '<td>' + escapeHtml(text(e.generated, '-')) + '</td>' +
      '<td>' + escapeHtml(text(e.stage, '-')) + '</td>' +
      '<td>' + escapeHtml(text(e.android_release, '?') + ' / ' + text(e.qpr, '?')) + '</td>' +
      '<td>' + escapeHtml(text(e.storage_type, '?')) + '</td>' +
      '<td>' + escapeHtml(text(e.created, '0')) + '</td>' +
      '<td>' + escapeHtml(text(e.failed, '0')) + '</td>' +
      '<td>' + escapeHtml(text(e.integrity, '?')) + '</td>' +
    '</tr>'
  ).join('');
}

async function load() {
  const bust = '?t=' + Date.now();
  try {
    const [reportResponse, historyResponse] = await Promise.all([
      fetch('data/report.json' + bust, { cache: 'no-store' }),
      fetch('data/history.jsonl' + bust, { cache: 'no-store' })
    ]);
    if (!reportResponse.ok) throw new Error('report.json is missing');
    const data = await reportResponse.json();
    renderReport(data);
    byId('subtitle').textContent = 'Updated ' + text(data.generated, 'never');
    renderHistory(historyResponse.ok ? await historyResponse.text() : '');
  } catch (error) {
    byId('subtitle').textContent = error.message;
    const pill = byId('statusPill');
    pill.className = 'status-pill bad';
    pill.textContent = 'Unavailable';
  }
}

document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
    document.querySelectorAll('.section').forEach((s) => s.classList.remove('active'));
    tab.classList.add('active');
    byId(tab.dataset.section).classList.add('active');
  });
});

byId('refreshBtn').addEventListener('click', load);
load();
setInterval(load, 15000);
