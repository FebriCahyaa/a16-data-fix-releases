# Dynamic native modules

This directory is populated by `scripts/collect-native.sh` from the NDK build.
Nothing here is committed as a prebuilt binary in the source repository.

```
lib/<abi>/liba16fix_crypto.so
lib/<abi>/liba16fix_core.so
lib/<abi>/liba16fix_fixes.so
```

`bin/<abi>/a16fixd` loads these libraries at runtime with `dlopen()` and calls
the single exported entry point `a16fix_module_init(A16FixContext *)`. All module
logic lives here; the `*.sh` files at the module root are only short
trampolines required by the root managers.

| Library | Responsibility |
| ------- | -------------- |
| `crypto` | SHA256 hashing and the known-answer self-test |
| `core` | F2FS/EXT4, Zygisk and metamodule detection, integrity check, report |
| `fixes` | Creates missing `Android/{data,obb,media}/<pkg>` folders only |

Supported ABIs: `arm64-v8a`, `armeabi-v7a`, `x86_64`.

(c) 2026 @FebriCahyaa. All rights reserved.
