# Zygisk presence reporter

This directory contains the Zygisk module built by NDK r27d in GitHub Actions:

```
zygisk/arm64-v8a.so
zygisk/armeabi-v7a.so
zygisk/x86_64.so
```

The `.so` files are never committed to the source repository. Actions runs
`scripts/collect-native.sh`, which copies `liba16fix_zygisk.so` from
`native/libs/<abi>/` to the names above.

## Behaviour

Source: `native/jni/zygisk_module.cpp`.

- `REGISTER_ZYGISK_MODULE(A16FixModule)` confirms the library loads in zygote.
- `REGISTER_ZYGISK_COMPANION(companion_handler)` answers with a ping.
- Reports the compiled API level (`v5`) to logcat.
- **No JNI hooks, no specialization changes, no app data access.** The storage
  repair runs as root in `a16fixd`, never inside an app process.

The installed Zygisk implementation and version are detected by the native core
from `ZYGISK_ENABLED`, the native bridge property, and installed modules such as
`zygisksu`, `ReZygisk` or `neozgisk`. It is reported in the Action output.

## Root solutions

| Root | Zygisk |
| ---- | ------ |
| Magisk | Built in; enable it in Settings. Do not enable ZygiskNext at the same time. |
| KernelSU / Next / SukiSU | No built-in Zygisk; install ZygiskNext (module id `zygisksu`). |
| APatch | No built-in Zygisk; install ZygiskNext / ReZygisk / NeoZygisk as an APM. |

Zygisk is not required for the storage fix; it is detected and reported only.
