#!/system/bin/sh
# Trampoline only. All module logic lives in a16fixd (NDK-built native core).
# If a root manager blocks native exec while installing, fall back to the system
# sha256sum so changed files are still identified. Never break the install.
# Copyright (c) 2026 @FebriCahyaa. All rights reserved.
D=${MODPATH:-${MODDIR:-${0%/*}}}
[ -d "$D/bin" ] || D=$(pwd)
A=$(getprop ro.product.cpu.abi 2>/dev/null)
echo "customize.sh reached D=$D A=$A" > /data/local/tmp/a16fix_install_trace 2>/dev/null
if [ ! -x "$D/bin/$A/a16fixd" ]; then
    for p in "$D"/bin/*/a16fixd; do
        [ -x "$p" ] || continue
        A=${p#*/bin/}
        A=${A%/a16fixd}
        break
    done
fi
if [ -x "$D/bin/$A/a16fixd" ]; then
    "$D/bin/$A/a16fixd" installer "$D"
    rc=$?
    echo "native installer rc=$rc" >> /data/local/tmp/a16fix_install_trace 2>/dev/null
    if [ "$rc" -eq 0 ]; then
        exit 0
    fi
    echo "a16_data_fix: native installer returned $rc, using shell fallback"
else
    echo "a16_data_fix: native core not found at $D/bin/$A/a16fixd"
fi
echo "- File integrity check (SHA256) [shell fallback]:"
if [ -f "$D/security/sha256.manifest" ] && command -v sha256sum >/dev/null 2>&1; then
    (cd "$D" && sha256sum -c security/sha256.manifest 2>&1) | grep -v ': OK$' || true
else
    echo "  manifest or sha256sum unavailable; boot-time native check still applies"
fi
echo "a16_data_fix: installation continues; custom patches stay off by default"
exit 0
