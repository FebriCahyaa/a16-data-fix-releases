# a16_data_fix security model

## 1. Single purpose

Since v1.5.0 the module only repairs the Android 16/17 QPR `Android/data` storage
bug. RIL, mount, filesystem repair, property injection, custom dynamic patches
and encrypted payloads have been removed from source and from the shipped ZIP.

The repair runs as root in the native core, never in an app process. It calls
`mkdir()` only for missing paths and never modifies existing app folders.

## 2. SHA256 integrity

`build.sh` generates `security/sha256.manifest` containing the SHA256 of every
shipped file, including all native binaries and the Zygisk `.so`.

`liba16fix_crypto.so` hashes every manifest entry with its own SHA256
implementation and runs a known-answer self-test for `"abc"` at startup. A
mismatch or a failed self-test marks integrity as `fail` and the fix is not
allowed to run. The `installer` and `verify` stages always verify, regardless of
configuration.

Install-time reporting is non-fatal because root managers may rewrite files
while extracting. `verify.sh` lists each `CHANGED` or `MISSING` file with its
expected and actual hash. `UNLISTED` manager markers such as `disable`,
`skip_mount` and `zygisk/unloaded` are informational.

The web UI writes `webroot/data/report.json` and `webroot/data/history.jsonl`
after each scan. Both are runtime state and are excluded from the manifest and
from the `UNLISTED` check, so the module never reports its own monitoring files
as tampering. `index.html`, `styles.css` and `app.js` remain hashed normally.

## 3. No metamodule=1

`metamodule=1` is deliberately omitted. KernelSU accepts only one active
metamodule, and a metamodule must provide `metamount.sh`. Marking this storage
fix as one would break mounting for other modules. Active metamodules are
detected for the report only.

CI scans the finished ZIP against the KernelSU-Next risk catalog so a plain
detection string cannot silently trigger a false security warning on install.

## 4. Zygisk

The Zygisk library is inert: no JNI hooks, no specialization changes, no app
data access. Zygisk is not required for the fix; its presence and version are
only reported.

## 5. sepolicy

No SELinux rule is shipped. Root can create and label the `media_rw` folders on
`/data/media` without an app-data rule. The module never touches `/data/data`
app contents.

## 6. Copyright

See `COPYRIGHT`. (c) 2026 @FebriCahyaa. All rights reserved.
