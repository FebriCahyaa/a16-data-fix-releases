# A16 Data Fix (Storage QPR) v1.5.0

**Author:** [@FebriCahyaa](https://github.com/FebriCahyaa)  
**Copyright:** (c) 2026 FebriCahyaa. All rights reserved. See `COPYRIGHT`.

A single native root module for **Magisk, KernelSU (including forks) and
APatch**. Target: **Android 16, 17 and newer**, all QPR channels, without kernel
patches.

Since v1.5.0 the module has **one job**: fix the Android 16+ QPR bug where the
per-app external folders under `Android/data`, `Android/obb` and `Android/media`
are never created. RIL, mount, filesystem repair, custom patches and encryption
have been removed.

| Repository | Visibility | Contents |
| ---------- | ---------- | -------- |
| `FebriCahyaa/a16-data-fix` | private | Source, native C/C++, Actions workflow |
| `FebriCahyaa/a16-data-fix-releases` | public | Built ZIP, `update.json`, `CHANGELOG.md`, release |

Update URL embedded in `module.prop`:

```
https://raw.githubusercontent.com/FebriCahyaa/a16-data-fix-releases/main/update.json
```

## What the fix does

On some Android 16/QPR ROMs `vold_prepare_subdirs` is denied by SELinux, so
`sys.user.0.ce_available` is never set and the per-app external folders are not
created. `getExternalFilesDir()` then fails and apps silently write to internal
storage instead.

At `post-fs-data` and again at `boot-completed`, the native `fixes` module:

1. enumerates installed packages from `/data/data`, `/data/app` and
   `/data/user/<n>`;
2. checks `/data/media/0/Android/{data,obb,media}/<pkg>` for every package;
3. creates **only missing** folders with owner `media_rw:media_rw` (1023:1023),
   mode `0777` and label `u:object_r:media_rw_data_file:s0`.

Existing folders are never chmod-changed, chowned, relabelled or deleted. This
is deliberately idempotent and cannot break an app whose folders already work.
No JNI hooks, no app-process file access, no remount, no property injection.
No bootloop by design.

After installing/updating: **reboot**, then force-stop and reopen any app that
was affected. Apps installed after the reboot get their folders on the next
reboot, or after the boot scan runs again.

## Automatic detection

The Action button and `/data/adb/a16_data_fix/module.log` show:

```
Android   : 16 (SDK 36) A16 QPR2 (estimated)
Internal  : f2fs source=/dev/block/dm-... opts=rw,...
Zygisk    : enabled impl=zygisksu version=2.1.0 api=v5
Metamodule: active=no id=none (NOT a metamodule)
Integrity : ok (engine native_sha256)
Android/data pass: scanned=123 created=45 failed=0
```

- **Internal storage**: read directly from `/proc/mounts` for the `/data`
  mount. Reports `f2fs`, `ext4` or `unknown`, plus the block device and mount
  options. There is no toggle for this.
- **Zygisk**: detects Magisk built-in Zygisk, ZygiskNext, ReZygisk, NeoZygisk
  and native-bridge based setups from environment variables, properties and
  installed module directories. Also reports the compiled Zygisk API level
  (`v5`). Zygisk is **not required** for the storage fix.
- **Metamodule**: detects an active metamodule via `/data/adb/metamodule` and
  known metamodule module IDs. This module deliberately does **not** set
  `metamodule=1` and never installs a `metamount.sh`, so it cannot displace
  another metamodule. CI scans the finished ZIP against the KernelSU-Next risk
  catalog to prevent a false security warning.

QPR channel names are estimates derived from the security patch date.

## Architecture

All runtime logic is **native C++17 built with Android NDK r27d** in GitHub
Actions. The `*.sh` files at the module root are only short trampolines that
find the right ABI and `exec` the real core:

```
customize.sh      -> a16fixd installer <moddir>
post-fs-data.sh   -> a16fixd post_fs_data <moddir>
boot-completed.sh -> a16fixd boot_completed <moddir>
action.sh         -> a16fixd action <moddir>
verify.sh         -> a16fixd verify <moddir>
uninstall.sh      -> a16fixd uninstall <moddir>
```

`service.sh` still calls the `late_start` stage for compatibility. The storage
repair runs at `post-fs-data`, at `boot-completed`, and again when the **Action**
button is pressed.

`a16fixd` loads three dynamic modules with `dlopen()`:

| Library | Responsibility |
| ------- | -------------- |
| `liba16fix_crypto.so` | SHA256 hashing and known-answer self-test |
| `liba16fix_core.so` | Detection, integrity check, report |
| `liba16fix_fixes.so` | Creates missing per-app `Android/*` folders |

The optional Zygisk `.so` is an inert presence reporter: no hooks, no app data
access. It does not perform the fix.

## Compatibility

| Root solution | Module path | Notes |
| ------------- | ----------- | ----- |
| Magisk | `/data/adb/modules` | Built-in Zygisk; >= 30.7 for A16 QPR2+, >= 31.1 for A17 |
| KernelSU / Next / SukiSU | `/data/adb/modules` | ZygiskNext optional; detected if present |
| APatch | `/data/adb/modules` | ZygiskNext / ReZygisk / NeoZygisk optional; detected if present |

Root detection uses `KSU=true`, `APATCH=true` and Magisk environment variables.
No kernel patching and no `metamodule=1`.

## Configuration

Edit the runtime copy only:

```
/data/adb/a16_data_fix/config.conf
```

Do not edit `config/config.conf` inside the module: it is part of the SHA256
manifest. The runtime copy is created from it on first boot. If it becomes
corrupt, delete it and reboot to regenerate it.

| Variable | Default | Purpose |
| -------- | ------- | ------- |
| `FIX_ANDROID_DATA` | 1 | Create only missing `Android/{data,obb,media}/<pkg>` folders |
| `REQUIRE_SHA256` | 1 | Verify the manifest before the fix runs |

Setting `FIX_ANDROID_DATA=0` disables the repair. Older runtime configs without
the key inherit the enabled default.

## Integrity

`build.sh` produces `security/sha256.manifest` for every shipped file, including
all native binaries. `a16fixd` verifies it natively before any fix runs. A
changed or missing file is named explicitly with expected and actual hashes.

Install-time reporting is non-fatal so a root manager that rewrites files
during extraction cannot break installation. Run `verify.sh` from the module
manager at any time for a detailed `OK / CHANGED / MISSING / UNLISTED` list.
`a16fixctl verify <manifest> <root>` provides the same check from a shell.

Trampolines restore executable bits and, if `/data/adb` is mounted `noexec`,
copy the core to `/data/local/tmp`. Debug details go to
`/data/local/tmp/a16fix_install_trace`.

## Build

GitHub Actions is authoritative:

1. push to `main` in the private source repo;
2. NDK r27d builds three ABIs;
3. `scripts/collect-native.sh` and `build.sh` create the ZIP and manifest;
4. ZIP validation and the KernelSU-Next risk check run;
5. the ZIP, `update.json` and `CHANGELOG.md` are published to the public
   releases repository and a GitHub Release.

Manual build requires a local NDK:

```sh
export ANDROID_NDK_HOME=/path/to/ndk/27.2.12479018
cd native/jni && ndk-build
cd ../.. && sh scripts/collect-native.sh && sh build.sh
```

Only the Actions build should be flashed.

## Limitations

- QPR detection is an estimate from the security patch date.
- Apps installed after a boot need the next boot scan (or reinstall/restart).
- Some ROMs may recreate the folders with their own labels later; the module
  only acts on folders that are actually missing.
- There are no kernel patches and no fstab changes.

(c) 2026 @FebriCahyaa. All rights reserved.
