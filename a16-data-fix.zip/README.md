# A16 Data Fix (Universal) v1.2.0

**Author:** [@FebriCahyaa](https://github.com/FebriCahyaa)  
**Copyright:** © 2026 FebriCahyaa. All rights reserved. Lihat `COPYRIGHT`.

Modul root **single ZIP** untuk Magisk, KernelSU (termasuk fork), dan APatch.
Target: **Android 16 dan 17 ke atas**, semua QPR, **tanpa patch kernel**.

| Repository | Visibilitas | Isi |
| ---------- | ----------- | --- |
| `FebriCahyaa/a16-data-fix` | **private** | source proyek, native C/C++, workflow Actions |
| `FebriCahyaa/a16-data-fix-releases` | public | ZIP hasil build, `update.json`, `CHANGELOG.md`, GitHub Release |

Manager root Mendapat update dari:

```
https://raw.githubusercontent.com/FebriCahyaa/a16-data-fix-releases/main/update.json
```

URL itu juga tertanam sebagai `updateJson` di `module.prop`.

## Penting: baca dulu

Modul ini adalah **framework diagnostik + perbaikan aman + slot patch**.
Modul **tidak** mengklaim memperbaiki bug tertentu karena detail bug belum
diberikan. Semua toggle perbaikan spesifik **mati secara default**.

Untuk mendapat patch yang benar, jalankan tombol **Action**, lalu kirim:

1. seluruh laporan dari Action,
2. `/data/adb/a16_data_fix/module.log`,
3. `logcat -b radio -d | tail -n 300` (masalah data seluler),
4. `dmesg | grep -iE 'f2fs|ext4|dm-verity|vold|ril'` (masalah mount/storage),
5. merek, tipe, ROM, versi root, dan `uname -r`.

## Kompatibilitas

| Root solution | Path modul | Catatan |
| ------------- | ---------- | ------- |
| Magisk | `/data/adb/modules` | Zygisk built-in; >= 30.7 untuk A16 QPR2+, >= 31.1 untuk A17 |
| KernelSU / Next / SukiSU | `/data/adb/modules` | Zygisk lewat ZygiskNext |
| APatch | `/data/adb/modules` | Zygisk lewat ZygiskNext / ReZygisk / NeoZygisk |

Deteksi memakai `KSU=true` / `APATCH=true`, fallback ke `magisk --path`.

### Android 17

Skripnya kompatibel (`SDK >= 36`, dan `SDK >= 37` dicatat sebagai
`ANDROID_IS_17_PLUS`). Yang menentukan keberhasilan adalah root solution:

- **Magisk**: >= 31.1.
- **KernelSU**: lebih ditentukan KMI kernel daripada nomor Android.
- **APatch**: kernel ARM64 3.18–6.12 dengan `CONFIG_KALLSYMS=y`.

Estimasi channel tetap berlabel **estimasi**.

## Fitur v1.2.0

### 1. Native nyata (bukan placeholder)

Dikompilasi dengan **Android NDK r27d** di GitHub Actions untuk 3 ABI:

```
bin/arm64-v8a/a16fixctl
bin/armeabi-v7a/a16fixctl
bin/x86_64/a16fixctl
zygisk/arm64-v8a.so
zygisk/armeabi-v7a.so
zygisk/x86_64.so
```

`a16fixctl` menyediakan:

```
a16fixctl sha256 <file>
a16fixctl verify <manifest> <root>
a16fixctl encrypt <keyfile> <in> <out>
a16fixctl decrypt <keyfile> <in> <out>
```

Enkripsi memakai **AES-256-CBC + HMAC-SHA256** (encrypt-then-MAC), bukan XOR.
Keyfile tidak dikirim di ZIP; pemilik perangkat memasangnya sendiri di
`/data/adb/a16_data_fix/keys/payload.key` (0600). Catatan batasan ada di
`SECURITY.md`.

### 2. Modul Zygisk nyata

`native/jni/zygisk_module.cpp` mendaftar dengan `REGISTER_ZYGISK_MODULE` dan
`REGISTER_ZYGISK_COMPANION`. Modul sengaja **inert**: hanya log dan menjawab
ping companion. Tidak ada hook JNI, tidak ada akses `/data/data`.

Deteksi: `ZYGISK_ENABLED=1`, native bridge, atau APM `zygisksu`/`ReZygisk`/
`neozgisk`. `ZYGISK_REQUIRED=1` membuat installer **gagal** bila Zygisk absent.

### 3. Metamodule-compatible (BUKAN metamodule)

Mendeteksi metamodule aktif (`/data/adb/metamodule`, `hybrid_mount`,
`meta-overlayfs`, `mountify`, dll) dan menampilkannya di Action.
`metamodule=1` sengaja tidak dipasang: KSU hanya izinkan satu metamodule dan
metamodule wajib punya `metamount.sh`.

### 4. Integritas SHA256

`build.sh` membuat `security/sha256.manifest` dari semua file modul,
termasuk binary native. `post-fs-data` memakai `a16fixctl verify`, fallback ke
`sha256sum -c`. Jika hash cocok ≠ patch kustom otomatis dimatikan.

### 5. Akses data aplikasi / sepolicy

Root (su) sudah memiliki akses penuh ke `/data/data`. Aturan SELinux adalah
contoh **opt-in** via `/data/adb/a16_data_fix/sepolicy.optin` sebelum flash.
Aturan salah bisa menggagalkan `magiskpolicy` saat pre-init.

## Build

### Via GitHub Actions (cara utama)

1. Push ke branch `main` repo private, atau klik **Run workflow**.
2. Actions: NDK r27d → `ndk-build` → `collect-native.sh` → `build.sh` → uji ZIP.
3. Actions push ZIP + `update.json` + `CHANGELOG.md` ke repo releases public.
4. Actions membuat/memperbarui Release `v<version>` dengan aset ZIP.
5. Modul yang terpasang akan melihat `updateJson` dan menawarkan update.

### Manual (butuh NDK lokal)

```sh
export ANDROID_NDK_HOME=/path/to/ndk/27.2.12479018
cd native/jni && ndk-build
cd ../.. && sh scripts/collect-native.sh && sh build.sh
```

Tanpa NDK, ZIP diagnostik tetap dibuat tetapi binary native tidak ada.

## Konfigurasi

Edit salinan runtime:

```
/data/adb/a16_data_fix/config.sh
```

Jangan edit `config/config.sh` di dalam modul — itu bagian dari hash SHA256.
Jangan edit file modul lain; verifikasi akan menolak patch kustom.

| Variabel | Default | Fungsi |
| -------- | ------- | ------ |
| `FIX_DATA_MOUNT` | 0 | Family perbaikan mount /data |
| `FIX_RIL` | 0 | Family perbaikan RIL |
| `FIX_FS` | 0 | Family perbaikan filesystem |
| `MOUNT_DATA_RW` | 1 | Remount /data rw jika ro |
| `ENSURE_DATA_DIRS` | 1 | Pastikan `/data/adb` ada |
| `INJECT_PROPS` | 0 | Terapkan property buatan |
| `RESTART_RILD` | 0 | Restart rild saat boot selesai |
| `USE_CUSTOM_PATCH_*` | 0 | Jalankan patch dari `patches/` |
| `REQUIRE_SHA256` | 1 | Verifikasi manifest sebelum patch |
| `USE_PROTECTED_PATCH` | 0 | `*.b64` (obfuscation) |
| `USE_NATIVE_CRYPTO` | 0 | `*.enc` AES+HMAC lewat a16fixctl |
| `NATIVE_KEYFILE` | `/data/adb/a16_data_fix/keys/payload.key` | Keyfile 0600 |
| `ZYGISK_REQUIRED` | 0 | Installer gagal bila Zygisk absent |

## Apa yang dilakukan tiap stage

- **post-fs-data**: deteksi lingkungan, ABI, native, Zygisk, metamodule;
  verifikasi SHA256; koreksi mount aman; patch kustom; inject property.
- **service**: `settings put global preferred_network_mode` bila diminta.
- **boot-completed**: opsi restart rild, laporan lengkap ke log.
- **action**: laporan + ABI/engine integritas + status Zygisk/metamodule.

## Keterbatasan

- fstab tidak bisa diperbaiki dari modul skrip (dipakai `init` lebih awal).
- Deteksi QPR hanya estimasi dari security patch.
- Tidak ada patch kernel.
- Zygisk inert sampai bug spesifik diketahui.
- Kunci enkripsi masih tertanam di biner; bukan HSM/server.
- Repo sources private berarti OTA bergantung repo releases public.

## Keamanan

Backup `/data` sebelum toggle berisiko; aktifkan satu toggle per kali.
Bootloop → Safe Mode / disable modul, lalu hapus
`/data/adb/a16_data_fix/config.sh`. Uninstall juga menghapus folder runtime.

## Struktur

```
a16-data-fix/
├── module.prop              (updateJson -> repo releases)
├── COPYRIGHT
├── SECURITY.md
├── CHANGELOG.md
├── customize.sh
├── post-fs-data.sh
├── service.sh
├── boot-completed.sh
├── action.sh
├── uninstall.sh
├── .github/workflows/build.yml
├── tools/make_update_json.py
├── native/
│   ├── README.md
│   ├── LICENSES.md
│   └── jni/                 (C/C++ + Android.mk + Application.mk)
├── scripts/                 (termasuk collect-native.sh, verify.sh, protect.sh)
├── config/config.sh
├── patches/
├── bin/<abi>/a16fixctl      (dari Actions)
├── zygisk/<abi>.so          (dari Actions)
├── security/sha256.manifest (dari build.sh)
└── build.sh
```
