# A16 Data Fix (Universal) v1.3.0

**Author:** [@FebriCahyaa](https://github.com/FebriCahyaa)  
**Copyright:** (c) 2026 FebriCahyaa. All rights reserved. See `COPYRIGHT`.

A **single ZIP** root module for Magisk, KernelSU (including forks) and APatch.
Target: **Android 16, 17 and newer**, all QPR channels, **without kernel patches**.

| Repository | Visibility | Contents |
| ---------- | ---------- | -------- |
| `FebriCahyaa/a16-data-fix` | **private** | Source, native C/C++, Actions workflow |
| `FebriCahyaa/a16-data-fix-releases` | public | Built ZIP, `update.json`, `CHANGELOG.md`, GitHub Release |

Installed managers check for updates at:

```
https://raw.githubusercontent.com/FebriCahyaa/a16-data-fix-releases/main/update.json
```

That URL is also embedded as `updateJson` in `module.prop`.

## Read this first

This module is a **native diagnostic framework + safe fixes + dynamic patch
slots**. It does **not** claim to fix a specific bug because no bug details
have been supplied yet. Every bug-specific toggle is **off by default**.

To get a real patch, press the **Action** button and send:

1. the full report from Action,
2. `/data/adb/a16_data_fix/module.log`,
3. `logcat -b radio -d | tail -n 300` (mobile data problems),
4. `dmesg | grep -iE 'f2fs|ext4|dm-verity|vold|ril'` (mount/storage problems),
5. device brand, model, ROM, root version and `uname -r`.

## Architecture

All runtime logic is **native C++17 built with the Android NDK**. The `*.sh`
files at the module root are small trampolines that only locate the right
ABI and `exec` the real core:

```
post-fs-data.sh  ->  bin/<abi>/a16fixd post_fs_data <moddir>
service.sh       ->  bin/<abi>/a16fixd late_start <moddir>
boot-completed.sh->  bin/<abi>/a16fixd boot_completed <moddir>
action.sh        ->  bin/<abi>/a16fixd action <moddir>
verify.sh        ->  bin/<abi>/a16fixd verify <moddir>
customize.sh     ->  bin/<abi>/a16fixd installer <moddir>
uninstall.sh     ->  bin/<abi>/a16fixd uninstall <moddir>
```

`a16fixd` loads small **dynamic modules** at runtime with `dlopen()`. Every
library exports exactly one symbol, `a16fix_module_init(A16FixContext *)`, so
each part can be replaced or extended without changing the core:

| Library | Responsibility |
| ------- | -------------- |
| `liba16fix_crypto.so` | SHA256 and AES-256-CBC + HMAC-SHA256 decryption |
| `liba16fix_core.so` | Environment detection, integrity check, report |
| `liba16fix_fixes.so` | Safe mount / filesystem / RIL actions, custom loading |
| `liba16fix_custom_{data,ril,fs}.so` | No-op templates for real bug fixes |

This is a real dynamic-package design, not a shell script wrapped in a binary.

## Compatibility

| Root solution | Module path | Notes |
| ------------- | ----------- | ----- |
| Magisk | `/data/adb/modules` | Built-in Zygisk; >= 30.7 for A16 QPR2+, >= 31.1 for A17 |
| KernelSU / Next / SukiSU | `/data/adb/modules` | Zygisk via ZygiskNext |
| APatch | `/data/adb/modules` | Zygisk via ZygiskNext / ReZygisk / NeoZygisk |

Detection uses `KSU=true` / `APATCH=true`, with `magisk --path` as fallback.

### Android 17

The native core is ABI-safe (`SDK >= 36`, with `SDK >= 37` recorded as
`ANDROID_IS_17_PLUS`). What really determines success is the root solution:

- **Magisk**: 31.1 or newer.
- **KernelSU**: depends more on the kernel KMI than on the Android number.
- **APatch**: ARM64 kernel 3.18-6.12 with `CONFIG_KALLSYMS=y`.

QPR channel labels are always marked as **estimates**.

## Features in v1.3.6

### 1. Fully native runtime

Compiled with **Android NDK r27d** in GitHub Actions for three ABIs:

```
bin/<abi>/a16fixd
bin/<abi>/a16fixctl
lib/<abi>/liba16fix_*.so        (6 dynamic modules)
zygisk/<abi>.so
```

`a16fixctl` remains available for maintenance:

```
a16fixctl sha256 <file>
a16fixctl verify <manifest> <root>
a16fixctl encrypt <keyfile> <in> <out>
a16fixctl decrypt <keyfile> <in> <out>
```

Encryption uses **AES-256-CBC + HMAC-SHA256** (encrypt-then-MAC). The keyfile
is not shipped in the ZIP; the device owner installs it at
`/data/adb/a16_data_fix/keys/payload.key` (mode 0600). Limitations are in
`SECURITY.md`.

### 2. Real Zygisk module

`native/jni/zygisk_module.cpp` registers with `REGISTER_ZYGISK_MODULE` and
`REGISTER_ZYGISK_COMPANION`. It is intentionally **inert**: log and companion
ping only. There are no JNI hooks and no access to `/data/data`.

Detection checks `ZYGISK_ENABLED=1`, the native bridge, or an APM such as
`zygisksu` / `ReZygisk` / `neozgisk`. `ZYGISK_REQUIRED=1` makes the installer
**abort** when Zygisk is missing.

### 3. Metamodule-compatible, but NOT a metamodule

It detects an active metamodule (`/data/adb/metamodule`, `hybrid_mount`,
`meta-overlayfs`, `mountify`, etc.) and shows it in the Action report.
`metamodule=1` is deliberately omitted: KernelSU accepts only one metamodule
and a metamodule requires `metamount.sh`.

### 4. SHA256 integrity

`build.sh` produces `security/sha256.manifest` from every shipped file,
including all native binaries. `a16fixd` verifies it natively before any fix
runs. A mismatch forces every custom module to be rejected and writes an error
to the log.

Two ways to inspect it:

```sh
# During installation (customize.sh), BEFORE anything else runs:
#   - File integrity check (SHA256):
#   CHANGED  lib/arm64-v8a/liba16fix_core.so
#            expected <sha256 from manifest>
#            actual   <sha256 computed on device>
#   WARNING: the files listed above were changed or added.
#   Custom patches are REJECTED until integrity is restored.

# Any time after installation, run verify.sh from the module manager:
# lists OK / CHANGED / MISSING / UNLISTED, then "Verify result: ok|fail".
```

`CHANGED` and `MISSING` fail verification. `UNLISTED` is reported for awareness
(user-supplied custom patches and manager markers are intentionally allowed).

### 5. App data access / sepolicy

Root already has full access to `/data/data`. SELinux rules are **opt-in** via
`/data/adb/a16_data_fix/sepolicy.optin` before flashing. A wrong rule can make
`magiskpolicy` fail during pre-init.

## Build

### GitHub Actions (primary path)

1. Push to `main` in the private repository, or click **Run workflow**.
2. Actions: NDK r27d -> `ndk-build` -> `collect-native.sh` -> `build.sh` -> ZIP validation.
3. Actions pushes the ZIP + `update.json` + `CHANGELOG.md` to the public releases repository.
4. Actions creates/updates Release `v<version>` with the ZIP asset.
5. Installed modules see `updateJson` and offer the update.

### Manual (requires a local NDK)

```sh
export ANDROID_NDK_HOME=/path/to/ndk/27.2.12479018
cd native/jni && ndk-build
cd ../.. && sh scripts/collect-native.sh && sh build.sh
```

Without the NDK, `build.sh` still produces a diagnostic ZIP but warns that the
native payload is missing. Only the Actions build should be flashed.

## Configuration

Edit the runtime copy:

```
/data/adb/a16_data_fix/config.conf
```

Do not edit `config/config.conf` inside the module: it is part of the SHA256
manifest. Do not edit other module files either; verification will reject
custom modules.

| Variable | Default | Purpose |
| -------- | ------- | ------- |
| `FIX_DATA_MOUNT` | 0 | `/data` mount fix family |
| `FIX_RIL` | 0 | RIL fix family |
| `FIX_FS` | 0 | Filesystem fix family |
| `MOUNT_DATA_RW` | 1 | Remount `/data` read-write if read-only |
| `ENSURE_DATA_DIRS` | 1 | Ensure `/data/adb` exists |
| `INJECT_PROPS` | 0 | Apply properties from `props.list` |
| `RESTART_RILD` | 0 | Restart rild at boot-completed |
| `USE_CUSTOM_PATCH_*` | 0 | Load `liba16fix_custom_*.so` |
| `REQUIRE_SHA256` | 1 | Verify manifest before any fix |
| `USE_NATIVE_CRYPTO` | 0 | Load encrypted `.so.enc` modules |
| `NATIVE_KEYFILE` | `/data/adb/a16_data_fix/keys/payload.key` | Keyfile, mode 0600 |
| `ZYGISK_REQUIRED` | 0 | Abort install when Zygisk is absent |

## What each stage does

- **post-fs-data**: detect environment/ABI/Zygisk/metamodule, verify SHA256,
  apply safe mount fixes, load custom modules, inject properties.
- **late_start**: `settings put global preferred_network_mode` when requested.
- **boot-completed**: optional rild restart, full report into the log.
- **action**: report plus integrity engine and Zygisk/metamodule status.
- **verify**: lists the status of every module file with expected/actual hashes
  for changed files; exits non-zero when verification fails.
- **installer**: verifies the whole ZIP first and identifies each changed file
  with expected/actual hashes. Reporting is always on, regardless of config. If
  the manager blocks native exec during install, `customize.sh` falls back to
  the system `sha256sum` and still exits 0, so installation cannot break. Custom
  patches stay rejected until integrity is restored.
- Managers that extract ZIP entries as `0644` are handled: every trampoline
  restores `chmod 0755` on `a16fixd`/`a16fixctl`, and falls back to copying the
  core into `/data/local/tmp` when `/data/adb` is mounted `noexec`.
- Debug: `/data/local/tmp/a16fix_install_trace` records whether `customize.sh`
  was reached, the `ls -l` of the ABI directory, and the native exit code.

## Limitations

- fstab cannot be fixed from a module: `init` consumes it much earlier.
- QPR detection is only an estimate from the security patch date.
- There are no kernel patches.
- The Zygisk module stays inert until a concrete bug is known.
- The decryption key is still embedded in source/binaries; it is not an HSM.
- A private source repository means OTA depends on the public releases repo.

## Safety

Back up `/data` before enabling risky toggles; enable one toggle at a time.
On a bootloop, use Safe Mode / disable the module, then remove
`/data/adb/a16_data_fix/config.conf`. Uninstall also removes the runtime folder.

## Repository structure

```
a16-data-fix/
|-- module.prop                  (updateJson -> public releases repo)
|-- COPYRIGHT
|-- SECURITY.md
|-- CHANGELOG.md
|-- README.md
|-- customize.sh                 (native trampoline)
|-- post-fs-data.sh              (native trampoline)
|-- service.sh                   (native trampoline)
|-- boot-completed.sh            (native trampoline)
|-- action.sh                    (native trampoline)
|-- verify.sh                    (native trampoline)
|-- uninstall.sh                 (native trampoline)
|-- sepolicy.rule.example
|-- config/config.conf           (runtime config template)
|-- native/                      (C/C++17 sources, NDK makefiles)
|-- scripts/collect-native.sh    (build helper)
|-- tools/make_update_json.py    (OTA helper)
|-- .github/workflows/build.yml  (NDK build + publish)
|-- patches/                     (custom module docs)
|-- bin/<abi>/                   (a16fixd, a16fixctl - from Actions)
|-- lib/<abi>/                   (6 dynamic modules - from Actions)
|-- zygisk/<abi>.so              (from Actions)
`-- security/sha256.manifest     (from build.sh)
```

(c) 2026 @FebriCahyaa. All rights reserved.
