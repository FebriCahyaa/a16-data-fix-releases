'use strict';

const TELEGRAM_USER = 'Fbrichyyy';
const TELEGRAM_LIMIT = 3000;
const byId = (id) => document.getElementById(id);

const latest = {
  report: null,
  history: [],
  updates: null,
  issueText: ''
};

function text(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback || '-';
  return String(value);
}

function escapeHtml(value) {
  return text(value, '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[c]);
}

function row(label, value) {
  return '<div class="row"><dt>' + escapeHtml(label) + '</dt><dd>' +
         escapeHtml(value) + '</dd></div>';
}

function shortDate(value) {
  return text(value, '-').replace('T', ' ').replace('Z', '').slice(0, 19);
}

function status(data) {
  if (data.integrity && data.integrity !== 'ok' && data.integrity !== 'skipped') {
    return ['bad', 'Integrity ' + data.integrity];
  }
  const failed = Number(data.failed || 0);
  const created = Number(data.created || 0);
  if (failed > 0) return ['warn', failed + ' folder' + (failed === 1 ? '' : 's') + ' failed'];
  if (created > 0) return ['good', 'Repaired ' + created + ' folder' + (created === 1 ? '' : 's')];
  return ['good', 'No missing folders'];
}

function renderReport(data) {
  byId('moduleName').textContent = text(data.module, 'QPR Storage Fix');
  byId('versionChip').textContent = 'v' + text(data.version, '--');
  byId('scanTime').textContent = text(data.generated, '-');
  byId('scanStage').textContent = data.stage
    ? 'Stage: ' + data.stage + ' | updated from the module scan'
    : 'No data yet. Reboot or press Action.';

  const [tone, label] = status(data);
  const pill = byId('statusPill');
  pill.className = 'status-pill ' + tone;
  pill.textContent = label;

  byId('statPackages').textContent = text(data.packages, '-');
  byId('statCreated').textContent = text(data.created, '-');
  byId('statFailed').textContent = text(data.failed, '-');

  byId('androidDetails').innerHTML =
    row('Release', text(data.android_release, 'unknown')) +
    row('SDK', text(data.android_sdk, 'unknown')) +
    row('Codename', text(data.android_codename, 'unknown')) +
    row('Build ID', text(data.android_build_id, 'unknown')) +
    row('Preview SDK', text(data.android_preview_sdk, '0')) +
    row('QPR', text(data.qpr, 'unknown')) +
    row('Detail', text(data.qpr_detail, 'unknown'));

  byId('storageDetails').innerHTML =
    row('Type', text(data.storage_type, 'unknown')) +
    row('Source', text(data.storage_source, 'unknown')) +
    row('Options', text(data.storage_options, 'unknown'));

  byId('zygiskDetails').innerHTML =
    row('Status', text(data.zygisk_status, 'unknown')) +
    row('Implementation', text(data.zygisk_impl, 'none')) +
    row('Version', text(data.zygisk_version, 'unknown')) +
    row('API', text(data.zygisk_api, 'unknown'));

  byId('safetyDetails').innerHTML =
    row('Root', text(data.root, 'unknown') + ' ' + text(data.root_version, '')) +
    row('Metamodule', data.metamodule_active ? 'active | ' + text(data.metamodule_id, 'unknown') : 'none') +
    row('Integrity', text(data.integrity, 'unknown')) +
    row('Engine', text(data.integrity_engine, 'none'));

  byId('rawJson').textContent = JSON.stringify(data, null, 2);
}

function parseHistory(raw) {
  const entries = [];
  for (const line of String(raw || '').split('\n')) {
    if (!line.trim()) continue;
    try { entries.push(JSON.parse(line)); } catch (ignored) { /* keep the table readable */ }
  }
  return entries;
}

function renderHistory(entries) {
  const body = byId('historyBody');
  if (entries.length === 0) {
    body.innerHTML = '<tr><td colspan="7" class="muted">No runs recorded yet.</td></tr>';
    return;
  }

  body.innerHTML = entries.slice().reverse().slice(0, 20).map((e) =>
    '<tr>' +
      '<td>' + escapeHtml(text(e.generated, '-')) + '</td>' +
      '<td>' + escapeHtml(text(e.stage, '-')) + '</td>' +
      '<td>' + escapeHtml(text(e.android_release, '?') + ' / ' + text(e.qpr, '?')) + '</td>' +
      '<td>' + escapeHtml(text(e.storage_type, '?')) + '</td>' +
      '<td>' + escapeHtml(text(e.created, '0')) + '</td>' +
      '<td>' + escapeHtml(text(e.failed, '0')) + '</td>' +
      '<td>' + escapeHtml(text(e.integrity, '?')) + '</td>' +
    '</tr>'
  ).join('');
}

function feedItem(meta, title, sub, url) {
  const tag = url ? 'a' : 'div';
  const link = url
    ? ' href="' + escapeHtml(url) + '" target="_blank" rel="noopener noreferrer"'
    : '';
  return '<' + tag + ' class="feed-item"' + link + '>' +
           '<div class="feed-meta">' + meta + '</div>' +
           '<div class="feed-title">' + escapeHtml(title) + '</div>' +
           '<div class="feed-sub">' + escapeHtml(sub) + '</div>' +
         '</' + tag + '>';
}

function renderUpdates(data) {
  const commits = (data && data.commits) || [];
  const issues = (data && data.issues) || [];

  byId('updatesMeta').textContent = data && data.generated !== 'never'
    ? text(data.generated) + ' | ' + text(data.repository)
    : 'No build snapshot yet';

  byId('issueMeta').textContent = data && data.issues_repository
    ? text(data.issues_repository) + ' | ' + issues.length + ' shown'
    : 'No issue snapshot yet';

  byId('commitList').innerHTML = commits.length
    ? commits.map((c) => feedItem(
        '<span class="badge">' + escapeHtml(text(c.sha, '?')) + '</span>',
        text(c.message, 'Untitled commit'),
        shortDate(c.date) + ' | ' + text(c.author, 'unknown'),
        c.url
      )).join('')
    : '<p class="muted">No commits in the build snapshot.</p>';

  byId('issueList').innerHTML = issues.length
    ? issues.map((i) => feedItem(
        '<span class="badge ' + escapeHtml(text(i.state).toLowerCase()) + '">#' +
          escapeHtml(text(i.number, '?')) + ' ' + escapeHtml(text(i.state, '?')) + '</span>',
        text(i.title, 'Untitled issue'),
        shortDate(i.date) + ' | ' + text(i.comments, '0') + ' comments',
        i.url
      )).join('')
    : '<p class="muted">No issues in the build snapshot.</p>';
}

function diagnose(report) {
  const found = [];
  const r = report || {};

  if (!r.generated || r.generated === 'never' || r.stage === 'waiting') {
    found.push('No scan result yet. Reboot or press Action once.');
  }
  if (r.integrity && r.integrity !== 'ok' && r.integrity !== 'skipped') {
    found.push('SHA256 integrity is ' + r.integrity + ' on engine ' +
               text(r.integrity_engine, 'none') + '.');
  }
  if (Number(r.failed || 0) > 0) {
    found.push(Number(r.failed) + ' Android/data folder creation(s) failed.');
  }
  if (text(r.android_release, 'unknown') === 'unknown') {
    found.push('Android release was not detected.');
  } else if (r.android_release !== '16' && r.android_release !== '17') {
    found.push('Android ' + r.android_release + ' is outside the tested 16/17 range.');
  }
  if (text(r.qpr, 'unknown') === 'unknown') {
    found.push('QPR channel was not detected.');
  }
  if (text(r.storage_type, 'unknown') === 'unknown') {
    found.push('Internal storage type was not read from /proc/mounts.');
  }
  if (text(r.root, 'unknown') === 'unknown') {
    found.push('Root solution was not detected from the module environment.');
  }
  if (r.metamodule_active) {
    found.push('A metamodule is active: ' + text(r.metamodule_id, 'unknown') + '.');
  }
  if (text(r.zygisk_status, 'unknown') === 'unknown') {
    found.push('Zygisk status could not be read. The repair itself does not need Zygisk.');
  }
  if (found.length === 0) {
    found.push('No automatic fault found in the local scan. Attach screenshots if folders are still missing.');
  }
  return found;
}

function buildIssueText() {
  const r = latest.report || {};
  const u = latest.updates || {};
  const lines = [];

  lines.push('QPR Storage Fix - issue report');
  lines.push('Send to: @' + TELEGRAM_USER);
  lines.push('Exported: ' + new Date().toISOString());
  lines.push('');
  lines.push('[Diagnostics]');
  diagnose(latest.report).forEach((item, index) => lines.push((index + 1) + '. ' + item));
  lines.push('');
  lines.push('[Device]');
  lines.push('Module   : ' + text(r.module, 'unknown') + ' v' + text(r.version, '?'));
  lines.push('Root     : ' + text(r.root, 'unknown') + ' ' + text(r.root_version, ''));
  lines.push('Android  : ' + text(r.android_release, 'unknown') +
             ' SDK ' + text(r.android_sdk, '?') +
             ' build ' + text(r.android_build_id, '?'));
  lines.push('QPR      : ' + text(r.qpr_detail, text(r.qpr, 'unknown')));
  lines.push('Storage  : ' + text(r.storage_type, 'unknown') +
             ' source ' + text(r.storage_source, '?'));
  lines.push('Zygisk   : ' + text(r.zygisk_status, 'unknown') +
             ' ' + text(r.zygisk_impl, 'none') +
             ' ' + text(r.zygisk_version, '?') +
             ' ' + text(r.zygisk_api, '?'));
  lines.push('Metamodule: ' + (r.metamodule_active
    ? 'active ' + text(r.metamodule_id, 'unknown') : 'none'));
  lines.push('Integrity: ' + text(r.integrity, 'unknown') +
             ' engine ' + text(r.integrity_engine, 'none'));
  lines.push('');
  lines.push('[Repair]');
  lines.push('Stage    : ' + text(r.stage, 'unknown'));
  lines.push('Scanned  : ' + text(r.packages, '0'));
  lines.push('Created  : ' + text(r.created, '0'));
  lines.push('Failed   : ' + text(r.failed, '0'));
  lines.push('');
  lines.push('[Build snapshot]');
  lines.push('Generated: ' + text(u.generated, 'unavailable'));
  lines.push('Repo     : ' + text(u.repository, 'unknown'));
  if ((u.commits || []).length) {
    lines.push('Commit   : ' + text(u.commits[0].sha, '?') + ' ' + text(u.commits[0].message, ''));
  }
  lines.push('');
  lines.push('[Recent runs]');
  latest.history.slice(-5).reverse().forEach((e) => {
    lines.push('- ' + text(e.generated, '?') + ' | ' + text(e.stage, '?') +
               ' | created ' + text(e.created, '0') +
               ' | failed ' + text(e.failed, '0') +
               ' | integrity ' + text(e.integrity, '?'));
  });
  lines.push('');
  lines.push('Attach a screenshot if Android/data is still empty after reboot.');

  return lines.join('\n');
}

function fitForTelegram(message) {
  if (message.length <= TELEGRAM_LIMIT) return message;
  return message.slice(0, TELEGRAM_LIMIT - 90) +
         '\n\n[truncated - download the .txt file for the full report]';
}

function openIssueModal() {
  latest.issueText = buildIssueText();
  byId('issueText').value = latest.issueText;
  byId('issueModal').hidden = false;
}

function closeIssueModal() {
  byId('issueModal').hidden = true;
}

function sendToTelegram() {
  const message = fitForTelegram(byId('issueText').value || latest.issueText);
  const url = 'https://t.me/' + TELEGRAM_USER + '?text=' + encodeURIComponent(message);
  const link = document.createElement('a');
  link.href = url;
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  document.body.appendChild(link);
  link.click();
  link.remove();
}

async function copyIssueText() {
  const value = byId('issueText').value || latest.issueText;
  try {
    await navigator.clipboard.writeText(value);
  } catch (ignored) {
    byId('issueText').focus();
    byId('issueText').select();
    if (document.execCommand) document.execCommand('copy');
  }
}

function downloadIssueText() {
  const value = byId('issueText').value || latest.issueText;
  const blob = new Blob([value], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'qpr-storage-fix-issue-' + Date.now() + '.txt';
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

async function load() {
  const bust = '?t=' + Date.now();
  try {
    const [reportResponse, historyResponse, updatesResponse] = await Promise.all([
      fetch('data/report.json' + bust, { cache: 'no-store' }),
      fetch('data/history.jsonl' + bust, { cache: 'no-store' }),
      fetch('data/updates.json' + bust, { cache: 'no-store' })
    ]);

    latest.report = reportResponse.ok ? await reportResponse.json() : null;
    latest.history = parseHistory(historyResponse.ok ? await historyResponse.text() : '');
    latest.updates = updatesResponse.ok ? await updatesResponse.json() : null;

    if (latest.report) {
      renderReport(latest.report);
      byId('subtitle').textContent = 'Updated ' + text(latest.report.generated, 'never');
    } else {
      byId('subtitle').textContent = 'report.json is missing';
      const pill = byId('statusPill');
      pill.className = 'status-pill bad';
      pill.textContent = 'Unavailable';
    }

    renderHistory(latest.history);
    renderUpdates(latest.updates);
  } catch (error) {
    byId('subtitle').textContent = error.message;
    const pill = byId('statusPill');
    pill.className = 'status-pill bad';
    pill.textContent = 'Unavailable';
  }
}

document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
    document.querySelectorAll('.section').forEach((s) => s.classList.remove('active'));
    tab.classList.add('active');
    byId(tab.dataset.section).classList.add('active');
  });
});

document.querySelectorAll('[data-close-modal]').forEach((node) => {
  node.addEventListener('click', closeIssueModal);
});

byId('refreshBtn').addEventListener('click', load);
byId('exportBtn').addEventListener('click', openIssueModal);
byId('telegramBtn').addEventListener('click', sendToTelegram);
byId('copyBtn').addEventListener('click', copyIssueText);
byId('downloadBtn').addEventListener('click', downloadIssueText);

load();
setInterval(load, 15000);
