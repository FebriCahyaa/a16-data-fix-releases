#!/system/bin/sh
# Trampoline only. All logic lives in a16fixd (NDK-built native core).
# Copyright (c) 2026 @FebriCahyaa. All rights reserved.
D=${0%/*}
A=$(getprop ro.product.cpu.abi 2>/dev/null)
exec "$D/bin/$A/a16fixd" late_start "$D"
