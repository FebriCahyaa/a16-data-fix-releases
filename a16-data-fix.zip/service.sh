#!/system/bin/sh
# a16_data_fix :: late_start service (non-blocking)
MODDIR=${0%/*}
STAGE=late_start

. "$MODDIR/scripts/common.sh"

init_runtime
load_config
detect_environment

log I "===== boot: late_start ====="

# settings command baru tersedia setelah framework jalan.
if [ "$FIX_RIL" = 1 ] && [ -n "$PREFERRED_NETWORK_MODE" ] && command -v settings >/dev/null 2>&1; then
    settings put global preferred_network_mode "$PREFERRED_NETWORK_MODE" 2>/dev/null \
        && log I "settings preferred_network_mode=$PREFERRED_NETWORK_MODE" \
        || log E "gagal menulis preferred_network_mode via settings"
fi

log I "late_start selesai"
exit 0
