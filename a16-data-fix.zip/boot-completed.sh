#!/system/bin/sh
# a16_data_fix :: boot-completed
# Copyright (c) 2026 @FebriCahyaa. All rights reserved.
MODDIR=${0%/*}
STAGE=boot_completed

. "$MODDIR/scripts/common.sh"
. "$MODDIR/scripts/verify.sh"
. "$MODDIR/scripts/detect-extras.sh"

init_runtime
load_config
detect_environment
detect_zygisk
detect_metamodule
verify_integrity || true
save_state

log I "===== boot: boot-completed ====="

# Restart rild SENGAGA opt-in. Bisa memutus jaringan sementara.
if [ "$FIX_RIL" = 1 ] && [ "$RESTART_RILD" = 1 ]; then
    for _svc in vendor.rild rild vendor.ril-daemon; do
        if [ -n "$(gp "init.svc.$_svc")" ]; then
            setprop "ctl.restart" "$_svc" 2>/dev/null
            log W "ctl.restart $_svc dikirim"
            break
        fi
    done
fi

report >>"$LOG_FILE" 2>/dev/null
log I "boot-completed selesai"
exit 0
