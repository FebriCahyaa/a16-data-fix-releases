# Custom patch slots

This folder holds documentation only. In v1.3.0 the patch slots are **native
dynamic modules**, not shell scripts:

```
lib/<abi>/liba16fix_custom_data.so     -> USE_CUSTOM_PATCH_DATA=1
lib/<abi>/liba16fix_custom_ril.so      -> USE_CUSTOM_PATCH_RIL=1
lib/<abi>/liba16fix_custom_fs.so       -> USE_CUSTOM_PATCH_FS=1
```

The shipped `custom_*.so` files are **no-op templates**. To create a real fix:

1. Edit the matching `native/jni/custom_<slot>.cpp`.
2. Keep the exported `a16fix_module_init(A16FixContext *)` entry point.
3. Rebuild with `ndk-build` and `scripts/collect-native.sh`.
4. Set the matching toggle in `/data/adb/a16_data_fix/config.conf`.
5. Verify SHA256 integrity passes (`REQUIRE_SHA256=1`).

## When to use a slot

Only fill a slot after the problem is known, for example from:

- the **Action** button in the root manager (short report),
- `logcat -b radio -d | tail -n 300`,
- `dmesg | grep -iE 'f2fs|ext4|dm-verity|vold|ril'`,
- `/data/adb/a16_data_fix/module.log`.

## Safety rules

1. Never touch `/data/user/*`, `/data/data` or metadata partitions.
2. Do not write fstab from a module: `init` consumes it much earlier.
3. Prefer `ctx->setprop_n(..., ..., no_block)` over raw `setprop` in post-fs-data.
4. Guard risky actions on `ctx->root_solution` and `ctx->android_sdk`.
5. Enable one toggle at a time so a bad fix is easy to roll back.

See `patches/protected/README.md` for encrypted module payloads.

(c) 2026 @FebriCahyaa. All rights reserved.
