# Slot patch spesifik

Folder ini sengaja berisi contoh yang **tidak aktif**. Modul tidak akan
menjalankan file apa pun di sini kecuali toggle `USE_CUSTOM_PATCH_*` di
`/data/adb/a16_data_fix/config.sh` diset ke `1`.

## Kapan dipakai

Isi slot hanya setelah masalahnya diketahui secara pasti, misalnya dari:

- tombol **Action** di manager root (laporan ringkas)
- `logcat -b radio -d | tail -n 300`
- `dmesg | grep -iE 'f2fs|ext4|dm-verity|vold|ril'`
- `/data/adb/a16_data_fix/module.log`

## File

| File             | Dipanggil dari      | Fungsi                                     |
| ---------------- | ------------------- | ------------------------------------------ |
| `data-mount.sh`  | `fix-data-mount.sh` | Koreksi mount /data, FBE, dm-verity        |
| `ril.sh`         | `fix-ril.sh`        | Property RIL, APN, mode jaringan           |
| `fs.sh`          | `fix-fs.sh`         | Opsi F2FS/EXT4, remount, flag khusus       |

Salin berkas `.example` ke nama tanpa `.example`, lalu isi. Semua file
dijalankan dengan `. file` (source), jadi bisa memakai helper `log`, `rp`,
`gp`, dan variabel hasil deteksi.

## Aturan keamanan

1. Jangan menyentuh `/data/user/*`, `/data/data`, atau partisi metadata.
2. Jangan menulis fstab dari modul - fstab dipakai init sebelum modul dimuat.
3. Jangan `setprop` di `post-fs-data`; pakai `rp` (resetprop -n).
4. Bungkus aksi berisiko dengan pengecekan `case "$ROOT_SOLUTION"`.
5. Uji satu toggle dalam satu waktu supaya mudah di-rollback.
