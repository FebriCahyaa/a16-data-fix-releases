# Encrypted dynamic modules

The only supported protected format is a real AES payload:

```
lib/<abi>/liba16fix_custom_<slot>.so.enc
```

Format: `"A16FIX01" | IV(16) | ciphertext | HMAC-SHA256(32)` using
AES-256-CBC + HMAC-SHA256 (encrypt-then-MAC).

## Creating an encrypted module

On a machine that has the keyfile, after `ndk-build`:

```sh
a16fixctl encrypt keyfile \
  lib/arm64-v8a/liba16fix_custom_ril.so \
  lib/arm64-v8a/liba16fix_custom_ril.so.enc
```

Repeat for every ABI you ship. Keep the plaintext `.so` out of the final ZIP if
you only want the encrypted payload; the core will decrypt the `.enc` file at
runtime.

## Running it on the device

Place the keyfile on the device:

```
/data/adb/a16_data_fix/keys/payload.key   # 128 hex digits, chmod 0600
```

then enable:

```
USE_NATIVE_CRYPTO=1
USE_CUSTOM_PATCH_RIL=1
```

The native core verifies the HMAC before decryption. A modified payload or a
wrong key is rejected and logged. Decrypted modules are written into the
runtime directory with mode 0600 and are never stored inside the module path.

## Limitation

The decryption routine itself is in the shipped native code. The device-side
keyfile is what actually gates execution; this raises the effort to tamper but
is not absolute protection. See `SECURITY.md` at the module root.

All files in this folder are hashed into `security/sha256.manifest`.

(c) 2026 @FebriCahyaa. All rights reserved.
