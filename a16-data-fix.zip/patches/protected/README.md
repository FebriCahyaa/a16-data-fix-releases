# Protected payload

Dua format didukung:

| Format | Dekoder | Keamanan |
| ------ | ------- | -------- |
| `*.b64` | `USE_PROTECTED_PATCH=1` | obfuscation, bukan enkripsi |
| `*.enc` | `USE_NATIVE_CRYPTO=1` | AES-256-CBC + HMAC-SHA256 |

## AES (disarankan)

Buat di mesin/build yang punya kunci:

```sh
a16fixctl encrypt keyfile patches/ril.sh patches/protected/ril.enc
```

Letakkan keyfile di perangkat:

```
/data/adb/a16_data_fix/keys/payload.key   # 128 digit hex, chmod 0600
```

lalu aktifkan:

```
USE_NATIVE_CRYPTO=1
USE_CUSTOM_PATCH_RIL=1
```

HMAC diverifikasi dulu; payload yang ditambahi character akan ditolak.

## Obfuscation (lama)

```sh
sh scripts/protect.sh encode patches/ril.sh patches/protected/ril.b64
```

Kuncinya ada di `scripts/protect.sh`, jadi siapa pun bisa membalikkannya.
Lihat `SECURITY.md` di root proyek.

Semua file di folder ini tetap masuk manifest SHA256.
