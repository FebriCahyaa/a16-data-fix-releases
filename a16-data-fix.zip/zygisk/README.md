# Zygisk support (native, nyata)

Folder ini berisi modul Zygisk hasil build NDK r27d di GitHub Actions:

```
zygisk/arm64-v8a.so
zygisk/armeabi-v7a.so
zygisk/x86_64.so
```

File `.so` **tidak di-commit** di repo proyek. Actions menjalankan
`scripts/collect-native.sh` yang menyalin `liba16fix_zygisk.so` dari
`native/libs/<abi>/` ke nama di atas. Build lokal tanpa NDK hanya akan
memuat `zygisk/README.md` dan memberi peringatan.

## Isi modul

Sumber: `native/jni/zygisk_module.cpp`.

- `REGISTER_ZYGISK_MODULE(A16FixModule)` — modul ter-load di zygote.
- `REGISTER_ZYGISK_COMPANION(companion_handler)` — companion root menjawab
  `A16FIX01 zygisk companion ok`.
- Sengaja **inert**: tidak meng-hook JNI, tidak mengubah argumen specialisasi,
  tidak menyentuh `/data/data`. Ini kerangka aman, bukan patch bootloop.

Api::getModuleDir() bisa dipakai nanti bila companion butuh membaca file modul.
Folder modul harus tetap readable zygote bila fitur itu diaktifkan.

## Root solution

| Root | Zygisk |
| ---- | ------ |
| Magisk | Built-in, aktifkan di Settings. Jangan aktifkan ZygiskNext bersamaan. |
| KernelSU / Next / SukiSU | Tidak ada built-in; pasang ZygiskNext (module id `zygisksu`). |
| APatch | Tidak ada built-in; ZygiskNext / ReZygisk / NeoZygisk sebagai APM. |

Deteksi di modul: `ZYGISK_ENABLED=1`, native bridge, atau APM `zygisksu`,
`ReZygisk`, `neozgisk`. `ZYGISK_REQUIRED=1` membuat installer gagal bila
Zygisk tidak tersedia.

## Build sendiri

Lihat `native/README.md`. Singkatnya:

```sh
cd native/jni && ndk-build
cd ../.. && sh scripts/collect-native.sh && sh build.sh
```
