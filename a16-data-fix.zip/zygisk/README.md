# Zygisk support (real native module)

This directory contains the Zygisk module built by NDK r27d in GitHub Actions:

```
zygisk/arm64-v8a.so
zygisk/armeabi-v7a.so
zygisk/x86_64.so
```

The `.so` files are never committed to the source repository. Actions runs
`scripts/collect-native.sh`, which copies `liba16fix_zygisk.so` from
`native/libs/<abi>/` to the names above.

## Behaviour

Source: `native/jni/zygisk_module.cpp`.

- `REGISTER_ZYGISK_MODULE(A16FixModule)` loads the module into zygote.
- `REGISTER_ZYGISK_COMPANION(companion_handler)` answers with
  `A16FIX01 zygisk companion ok`.
- Intentionally **inert**: no JNI hooks, no changes to specialization
  arguments, no access to `/data/data`. This is a safe native framework, not
  a bootloop-prone patch.

`Api::getModuleDir()` can be used later if the companion needs to read module
files. The module directory must remain zygote-readable if that is enabled.

## Root solutions

| Root | Zygisk |
| ---- | ------ |
| Magisk | Built in; enable it in Settings. Do not enable ZygiskNext at the same time. |
| KernelSU / Next / SukiSU | No built-in Zygisk; install ZygiskNext (module id `zygisksu`). |
| APatch | No built-in Zygisk; install ZygiskNext / ReZygisk / NeoZygisk as an APM. |

Detection checks `ZYGISK_ENABLED=1`, the native bridge, or an APM such as
`zygisksu`, `ReZygisk`, `neozgisk`. `ZYGISK_REQUIRED=1` aborts installation
when Zygisk is unavailable.

## Building

See `native/README.md`. In short:

```sh
cd native/jni && ndk-build
cd ../.. && sh scripts/collect-native.sh && sh build.sh
```
