#!/system/bin/sh
# Hapus data runtime (config + log) saat modul di-uninstall.
# Modul tidak menyimpan apa pun di /system maupun partisi lain.
rm -rf /data/adb/a16_data_fix 2>/dev/null
exit 0
