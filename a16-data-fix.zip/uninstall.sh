#!/system/bin/sh
# Trampoline only. All logic lives in a16fixd (NDK-built native core).
# Copyright (c) 2026 @FebriCahyaa. All rights reserved.
D=${MODPATH:-${MODDIR:-${0%/*}}}
[ -d "$D/bin" ] || D=$(pwd)
A=$(getprop ro.product.cpu.abi 2>/dev/null)
if [ ! -x "$D/bin/$A/a16fixd" ]; then
    for p in "$D"/bin/*/a16fixd; do
        [ -x "$p" ] || continue
        A=${p#*/bin/}
        A=${A%/a16fixd}
        break
    done
fi
[ -x "$D/bin/$A/a16fixd" ] || exit 1
exec "$D/bin/$A/a16fixd" uninstall "$D"
