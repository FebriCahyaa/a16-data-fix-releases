# Model keamanan a16_data_fix

## 1. Integritas SHA256 (NYATA)

`build.sh` membuat `security/sha256.manifest` berisi hash SHA256 dari semua
file yang dikirim, termasuk binary native dan `.so` Zygisk.

Saat `post-fs-data`, `scripts/verify.sh`:

1. memakai `a16fixctl verify` bila binary tersedia untuk ABI perangkat,
2. fallback ke `sha256sum -c` bila tidak ada,
3. mencatat engine yang dipakai di laporan Action.

- Cocok → patch kustom boleh jalan.
- Tidak cocok → semua `USE_CUSTOM_PATCH_*` dipaksa `0`, error masuk log.
- Kedua engine tidak ada → verifikasi dilewati dan dicatat, modul tetap aman
  dalam mode diagnostik.

## 2. Enkripsi payload (NYATA, dengan catatan)

`a16fixctl encrypt/decrypt` memakai **AES-256-CBC + HMAC-SHA256**
(encrypt-then-MAC), bukan XOR/obfuscation:

```
"A16FIX01" | IV(16) | ciphertext(PKCS#7) | HMAC-SHA256(32)
```

HMAC diverifikasi dengan `constant_time_eq` sebelum dekripsi. Payload yang
diubah atau keyfile salah ditolak.

Kunci AES+HMAC dibangkitkan sebagai Secrets di repo **proyek private** dan
dipakai saat build. Keyfile **tidak** dikirim di ZIP. Pemilik perangkat
memasangnya sendiri di:

```
/data/adb/a16_data_fix/keys/payload.key   # 128 digit hex, chmod 0600
```

lalu `USE_NATIVE_CRYPTO=1`.

**Batasan jujur:** kunci decrypt tetap ada di source/biner `a16fixctl`, jadi
orang yang mendapat ZIP bisa mengekstraknya. Ini menaikkan usaha, bukan
perlindungan absolut. Perlindungan sejati butuh kunci di luar perangkat.

Mode lama `USE_PROTECTED_PATCH=1` (`*.b64`, byte +17 + base64) masih ada,
tetapi hanya **obfuscation** dan tidak boleh disebut enkripsi.

## 3. Tidak ada metamodule=1

`metamodule=1` sengaja **tidak** dipasang. KernelSU hanya menerima satu
metamodule aktif dan metamodule wajib punya `metamount.sh`. Modul ini hanya
companion/terdeteksi, jadi memaksanya jadi metamodule akan merusak mounting
modul lain.

## 4. sepolicy

`sepolicy.rule.example` tidak aktif. Aturan SELinux yang salah (domain tidak
ada di build tertentu) bisa membuat `magiskpolicy` gagal saat pre-init.
Aktifkan hanya lewat `/data/adb/a16_data_fix/sepolicy.optin` setelah memeriksa
`su -c 'id -Z'`.

## 5. Zygisk

Modul native Zygisk sengaja inert: tidak hook, tidak menyentuh data aplikasi.
Ini mengurangi risiko bootloop/penyalahgunaan. Companion hanya menjawab ping.

## 6. Hak cipta

Lihat `COPYRIGHT`. © 2026 @FebriCahyaa. All rights reserved.
