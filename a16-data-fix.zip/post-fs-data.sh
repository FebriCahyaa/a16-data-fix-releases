#!/system/bin/sh
# a16_data_fix :: post-fs-data (BLOCKING - jangan berat)
# Copyright (c) 2026 @FebriCahyaa. All rights reserved.
MODDIR=${0%/*}
STAGE=post_fs_data

. "$MODDIR/scripts/common.sh"
. "$MODDIR/scripts/verify.sh"
. "$MODDIR/scripts/protect.sh"
. "$MODDIR/scripts/detect-extras.sh"
. "$MODDIR/scripts/fix-data-mount.sh"
. "$MODDIR/scripts/fix-fs.sh"
. "$MODDIR/scripts/fix-ril.sh"

init_runtime
load_config
detect_environment
detect_zygisk
detect_metamodule

if ! verify_integrity; then
    # Jangan pernah menjalankan patch kustom dari file yang sudah diubah.
    USE_CUSTOM_PATCH_DATA=0
    USE_CUSTOM_PATCH_RIL=0
    USE_CUSTOM_PATCH_FS=0
fi

save_state

log I "===== boot: post-fs-data ====="
log I "root=$ROOT_SOLUTION/$ROOT_VERSION android=$ANDROID_RELEASE sdk=$ANDROID_SDK qpr=$ANDROID_QPR"
log I "kernel=$KERNEL_RELEASE kmi=$KMI /data=$DATA_FSTYPE crypto=$CRYPTO_TYPE"
log I "zygisk=$ZYGISK_STATUS/$ZYGISK_IMPL metamodule=$METAMODULE_ID integrity=$INTEGRITY_STATUS"

if [ "$ANDROID_IS_16_PLUS" != 1 ]; then
    log W "perangkat bukan Android 16+ (SDK < 36); tetap lanjut dengan mode diagnostik"
fi

fix_data_mount
fix_fs
fix_ril
apply_custom_props

log I "post-fs-data selesai"
exit 0
