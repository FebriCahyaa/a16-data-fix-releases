#!/system/bin/sh
# a16_data_fix :: installer (Magisk / KernelSU / APatch)
# Copyright (c) 2026 @FebriCahyaa. All rights reserved.

MODPATH=${MODPATH:-$(dirname "$0")}

if ! command -v ui_print >/dev/null 2>&1; then
    ui_print() { echo "$@"; }
fi
_abort() {
    if command -v abort >/dev/null 2>&1; then
        abort "$1"
    fi
    echo "ABORT: $1" >&2
    exit 1
}

ui_print "=========================================="
ui_print " A16 Data Fix (Universal) v1.2.0"
ui_print " Copyright (c) 2026 @FebriCahyaa"
ui_print " All rights reserved."
ui_print "=========================================="

# --- Deteksi root ------------------------------------------------------------
if [ "$KSU" = true ]; then
    ROOT=kernelsu
    ui_print "- Root: KernelSU family"
elif [ "$APATCH" = true ]; then
    ROOT=apatch
    ui_print "- Root: APatch"
elif [ -n "$MAGISK_VER_CODE" ] || command -v magisk >/dev/null 2>&1; then
    ROOT=magisk
    ui_print "- Root: Magisk ${MAGISK_VER:-unknown}"
else
    ROOT=unknown
    ui_print "! Root tidak terdeteksi; skrip tetap dipasang"
fi

# --- Siapkan konfigurasi awal ------------------------------------------------
mkdir -p /data/adb/a16_data_fix 2>/dev/null
if [ ! -f /data/adb/a16_data_fix/config.sh ]; then
    cp "$MODPATH/config/config.sh" /data/adb/a16_data_fix/config.sh 2>/dev/null || true
    chmod 0600 /data/adb/a16_data_fix/config.sh 2>/dev/null || true
fi

ZYGISK_REQUIRED=0
if [ -f /data/adb/a16_data_fix/config.sh ]; then
    . /data/adb/a16_data_fix/config.sh
fi

# --- Deteksi Zygisk ----------------------------------------------------------
ZYG_OK=0
[ "$ZYGISK_ENABLED" = 1 ] && ZYG_OK=1
for _z in zygisksu ReZygisk ReZygisk_Next neozgisk neozygisk; do
    [ -d "/data/adb/modules/$_z" ] && ZYG_OK=1
done
if [ "$ZYG_OK" = 1 ]; then
    ui_print "- Zygisk: tersedia (fitur lanjutan diaktifkan)"
else
    ui_print "- Zygisk: tidak terdeteksi"
    if [ "$ZYGISK_REQUIRED" = 1 ]; then
        _abort "ZYGISK_REQUIRED=1 tetapi Zygisk tidak tersedia. Pasang ZygiskNext/ReZygisk atau aktifkan Zygisk bawaan Magisk."
    fi
fi

# --- Deteksi metamodule ------------------------------------------------------
MM_ID=none
[ -L /data/adb/metamodule ] && MM_ID=$(basename "$(readlink /data/adb/metamodule 2>/dev/null)" 2>/dev/null)
for _m in hybrid_mount meta-overlayfs meta-overlay mountify meta-mm meta_magic_mount nomount zeromount; do
    [ -d "/data/adb/modules/$_m" ] && [ "$MM_ID" = none ] && MM_ID=$_m
done
ui_print "- Metamodule terdeteksi: $MM_ID"
ui_print "- Modul ini kompatibel dengan metamodule, tapi BUKAN metamodule."
ui_print "  (metamodule=1 sengaja tidak dipakai: KSU hanya izinkan satu)."

# --- sepolicy opt-in ---------------------------------------------------------
if [ -f /data/adb/a16_data_fix/sepolicy.optin ] && [ -f "$MODPATH/sepolicy.rule.example" ]; then
    cp "$MODPATH/sepolicy.rule.example" "$MODPATH/sepolicy.rule" 2>/dev/null || true
    ui_print "- sepolicy.rule AKTIF dari berkas opt-in"
else
    rm -f "$MODPATH/sepolicy.rule" 2>/dev/null || true
    ui_print "- sepolicy.rule tidak aktif (root sudah punya akses /data/data)"
fi

# --- Izin file ---------------------------------------------------------------
for f in "$MODPATH"/*.sh "$MODPATH"/scripts/*.sh; do
    [ -f "$f" ] && chmod 0755 "$f" 2>/dev/null
done
chmod 0644 "$MODPATH/module.prop" 2>/dev/null
chmod 0644 "$MODPATH/config/config.sh" 2>/dev/null
chmod 0644 "$MODPATH/security/sha256.manifest" 2>/dev/null || true

NATIVE_COUNT=0
for f in "$MODPATH"/bin/*/a16fixctl; do
    [ -f "$f" ] || continue
    chmod 0755 "$f" 2>/dev/null
    NATIVE_COUNT=$((NATIVE_COUNT + 1))
done
ZYGISK_SO_COUNT=0
for f in "$MODPATH"/zygisk/*.so; do
    [ -f "$f" ] || continue
    chmod 0644 "$f" 2>/dev/null
    ZYGISK_SO_COUNT=$((ZYGISK_SO_COUNT + 1))
done
ui_print "- Native: a16fixctl x$NATIVE_COUNT, zygisk .so x$ZYGISK_SO_COUNT"
if [ "$ZYGISK_SO_COUNT" -eq 0 ]; then
    ui_print "  (!) ZIP ini tanpa native; flash hasil GitHub Actions untuk build nyata."
fi

ui_print "- Integritas: manifest SHA256 diverifikasi saat boot."
ui_print "- OTA: updateJson mengarah ke repo releases GitHub."
if [ "$ROOT" = magisk ]; then
    ui_print "- Android 16 QPR2+: Magisk >= 30.7 disarankan"
    ui_print "- Android 17: Magisk >= 31.1 disarankan"
fi
ui_print "- Semua perbaikan spesifik MATI secara default."
ui_print "- Action -> lihat diagnostik, atau edit:"
ui_print "  /data/adb/a16_data_fix/config.sh"
ui_print "=========================================="
exit 0
