#!/system/bin/sh
# Trampoline only. All installer logic lives in a16fixd (NDK-built native core).
# Copyright (c) 2026 @FebriCahyaa. All rights reserved.
D=${MODPATH:-${MODDIR:-${0%/*}}}
[ -d "$D/bin" ] || D=$(pwd)
A=$(getprop ro.product.cpu.abi 2>/dev/null)
if [ ! -x "$D/bin/$A/a16fixd" ]; then
    for p in "$D"/bin/*/a16fixd; do
        [ -x "$p" ] || continue
        A=${p#*/bin/}
        A=${A%/a16fixd}
        break
    done
fi
if [ ! -x "$D/bin/$A/a16fixd" ]; then
    echo "a16_data_fix: native core missing at $D/bin/$A/a16fixd" >&2
    exit 1
fi
exec "$D/bin/$A/a16fixd" installer "$D"
