# Dynamic native modules

This directory is populated by `scripts/collect-native.sh` from the NDK build.
Nothing here is committed as a prebuilt binary in the source repository.

```
lib/<abi>/liba16fix_crypto.so
lib/<abi>/liba16fix_core.so
lib/<abi>/liba16fix_fixes.so
lib/<abi>/liba16fix_custom_data.so
lib/<abi>/liba16fix_custom_ril.so
lib/<abi>/liba16fix_custom_fs.so
```

`bin/<abi>/a16fixd` loads these libraries at runtime with `dlopen()` and calls
the single exported entry point `a16fix_module_init(A16FixContext *)`. All
module logic lives here; the `*.sh` files at the module root are only short
trampolines required by the root managers.

| Library | Responsibility |
| ------- | -------------- |
| `crypto` | SHA256 hashing and AES-256-CBC + HMAC-SHA256 decryption |
| `core` | Environment detection, SHA256 verification, diagnostic report |
| `fixes` | Safe mount / filesystem / RIL actions and custom module loading |
| `custom_data`, `custom_ril`, `custom_fs` | No-op templates; replace with real bug fixes and rebuild |

Supported ABIs: `arm64-v8a`, `armeabi-v7a`, `x86_64`.

(c) 2026 @FebriCahyaa. All rights reserved.
