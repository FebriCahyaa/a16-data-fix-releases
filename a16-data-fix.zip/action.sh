#!/system/bin/sh
# a16_data_fix :: tombol Action di manager root
# Copyright (c) 2026 @FebriCahyaa. All rights reserved.
MODDIR=${0%/*}
STAGE=action
VERBOSE=1

. "$MODDIR/scripts/common.sh"
. "$MODDIR/scripts/verify.sh"
. "$MODDIR/scripts/detect-extras.sh"

init_runtime
load_config
detect_environment
detect_zygisk
detect_metamodule
verify_integrity || true
save_state

report
printf '\n--- 30 baris log terakhir ---\n'
tail -n 30 "$LOG_FILE" 2>/dev/null
printf '\nLengkap: %s\n' "$LOG_FILE"
exit 0
