# ============================================================================
# a16_data_fix :: KONFIGURASI
# ----------------------------------------------------------------------------
# File default ini akan disalin ke:
#   /data/adb/a16_data_fix/config.sh
# pada boot pertama. Edit SALINAN itu, bukan file di dalam ZIP/modul.
#
# Nilai 0 = mati, 1 = hidup. Semua perbaikan spesifik MATI secara default
# supaya modul tidak pernah membuat bootloop sebelum masalahnya diketahui.
# ============================================================================

# --- Kelompok perbaikan utama ------------------------------------------------
FIX_DATA_MOUNT=0        # Penanganan mount partisi /data
FIX_RIL=0               # Penanganan RIL / data seluler
FIX_FS=0                # Penanganan filesystem F2FS/EXT4

# --- Aksi generik yang relatif aman ------------------------------------------
MOUNT_DATA_RW=1         # Jika /data terdeteksi ro, coba remount rw
ENSURE_DATA_DIRS=1      # Pastikan /data/adb ada (tidak menyentuh /data/user/*)
INJECT_PROPS=0          # Terapkan property dari CUSTOM_PROPS / props.list
RESTART_RILD=0          # Restart rild di boot-completed (hati-hati!)
FS_REMOUNT_NOATIME=0    # Remount /data dengan noatime (opt-in, performa)

# --- Slot patch spesifik -----------------------------------------------------
# Isi dulu file yang bersangkutan di folder patches/, lalu aktifkan di sini.
# Jangan aktifkan tanpa tahu persis bug-nya.
USE_CUSTOM_PATCH_DATA=0     # patches/data-mount.sh
USE_CUSTOM_PATCH_RIL=0      # patches/ril.sh
USE_CUSTOM_PATCH_FS=0       # patches/fs.sh

# --- Keamanan & kompatibilitas ----------------------------------------------
REQUIRE_SHA256=1            # Verifikasi manifest SHA256 sebelum patch jalan
USE_PROTECTED_PATCH=0       # Pakai patch terenkripsi / terproteksi
USE_NATIVE_CRYPTO=0         # 1 = pakai a16fixctl (AES-256-CBC + HMAC), butuh keyfile
NATIVE_KEYFILE=/data/adb/a16_data_fix/keys/payload.key  # 128 digit hex, 0600
ZYGISK_REQUIRED=0           # 1 = installer gagal bila Zygisk tidak tersedia

# --- Property khusus RIL (hanya dipakai jika FIX_RIL=1 & INJECT_PROPS=1) -----
# Contoh: 10 = LTE/GSM auto, 1 = GSM only, 0 = global
PREFERRED_NETWORK_MODE=

# --- Property tambahan bebas -------------------------------------------------
# Satu property per baris, format: nama= nilai
CUSTOM_PROPS="
# ro.example.property=value
# persist.radio.example=value
"
