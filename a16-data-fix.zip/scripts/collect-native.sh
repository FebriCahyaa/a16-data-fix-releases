#!/bin/sh
# Salin hasil ndk-build ke struktur modul.
# Dipanggil oleh GitHub Actions setelah ndk-build.
# Copyright (c) 2026 @FebriCahyaa. All rights reserved.
set -e

ROOT=$(cd "$(dirname "$0")/.." && pwd)
LIBS="$ROOT/native/libs"
ABIS="arm64-v8a armeabi-v7a x86_64"

for abi in $ABIS; do
    ctl="$LIBS/$abi/a16fixctl"
    so="$LIBS/$abi/liba16fix_zygisk.so"

    [ -f "$ctl" ] || { echo "ERROR: tidak ada $ctl" >&2; exit 1; }
    [ -f "$so" ] || { echo "ERROR: tidak ada $so" >&2; exit 1; }

    # Pastikan benar-benar ELF, bukan placeholder teks.
    file "$ctl" | grep -q 'ELF' || { echo "ERROR: $ctl bukan ELF" >&2; exit 1; }
    file "$so" | grep -q 'ELF' || { echo "ERROR: $so bukan ELF" >&2; exit 1; }

    mkdir -p "$ROOT/bin/$abi"
    cp "$ctl" "$ROOT/bin/$abi/a16fixctl"
    chmod 0755 "$ROOT/bin/$abi/a16fixctl"

    cp "$so" "$ROOT/zygisk/$abi.so"
    chmod 0644 "$ROOT/zygisk/$abi.so"

    echo "collected $abi: a16fixctl + zygisk/$abi.so"
done
