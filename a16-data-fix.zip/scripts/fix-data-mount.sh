#!/system/bin/sh
# a16_data_fix :: penanganan mount /data
# Catatan: skrip modul berjalan SETELAH /data selesai di-mount. Mount awal
# dikendalikan fstab/vold di init, jadi modul tidak bisa memperbaiki fstab
# yang salah tanpa patch ramdisk/kernel. Fungsi di sini hanya melakukan
# koreksi aman pasca-mount dan menyediakan slot patch buatan Anda.

fix_data_mount() {
    log I "fix-data-mount: mulai (fstype=$DATA_FSTYPE)"

    if [ "$FIX_DATA_MOUNT" != 1 ]; then
        log I "fix-data-mount: dimatikan oleh config"
        return 0
    fi

    if [ "$MOUNT_DATA_RW" = 1 ]; then
        case ",$DATA_OPTS," in
            *,ro,*)
                log W "/data terdeteksi read-only, mencoba remount rw"
                if mount -o remount,rw /data 2>/dev/null; then
                    log I "remount /data rw berhasil"
                    DATA_OPTS=$(awk '$2 == "/data" { print $4; exit }' /proc/mounts 2>/dev/null)
                else
                    log E "remount /data rw GAGAL - cek dmesg"
                fi
                ;;
            *)
                log I "/data sudah rw, remount tidak diperlukan"
                ;;
        esac
    fi

    if [ "$ENSURE_DATA_DIRS" = 1 ]; then
        # Sengaja hanya /data/adb. Jangan pernah membuat /data/user/<id>
        # atau /data/data karena dikelola vold dan bisa merusak FBE.
        if [ ! -d /data/adb ]; then
            if mkdir -p /data/adb 2>/dev/null; then
                log I "dibuat: /data/adb"
            else
                log E "gagal membuat /data/adb"
            fi
        fi
        if command -v restorecon >/dev/null 2>&1; then
            restorecon -R "$RUNTIME_DIR" 2>/dev/null || true
        fi
    fi

    if [ "$USE_CUSTOM_PATCH_DATA" = 1 ]; then
        load_patch data-mount
    fi

    log I "fix-data-mount: selesai"
    return 0
}
