#!/system/bin/sh
# a16_data_fix :: penanganan RIL / data seluler
# Perubahan property dilakukan di post-fs-data via resetprop -n supaya
# diamankan dari deadlock. Aksi yang butuh framework (settings, restart rild)
# ada di service.sh / boot-completed.sh.

fix_ril() {
    log I "fix-ril: mulai (rild=$RILD_PRESENT network=$RIL_DEFAULT_NETWORK)"

    if [ "$FIX_RIL" != 1 ]; then
        log I "fix-ril: dimatikan oleh config"
        return 0
    fi

    if [ "$RILD_PRESENT" = 0 ]; then
        log W "tidak ada layanan rild terdeteksi - perangkat mungkin WiFi-only"
    fi

    if [ -n "$PREFERRED_NETWORK_MODE" ]; then
        if [ "$INJECT_PROPS" = 1 ]; then
            rp ro.telephony.default_network "$PREFERRED_NETWORK_MODE"
            log I "ro.telephony.default_network -> $PREFERRED_NETWORK_MODE"
        else
            log W "PREFERRED_NETWORK_MODE diisi tetapi INJECT_PROPS=0, diabaikan"
        fi
    fi

    if [ "$USE_CUSTOM_PATCH_RIL" = 1 ]; then
        load_patch ril
    fi

    log I "fix-ril: selesai"
    return 0
}
