#!/system/bin/sh
# a16_data_fix :: protected payload
# ------------------------------------------------------------------
# Dua mode:
#  1. NATIVE (nyata): a16fixctl decrypt -> AES-256-CBC + HMAC-SHA256
#     Payload: patches/protected/<nama>.enc
#     Keyfile: /data/adb/a16_data_fix/keys/payload.key (128 digit hex, 0600)
#     Keyfile TIDAK dikirim di ZIP. Harus dipasang manual oleh pemilik perangkat.
#  2. OBFUSCATION (bukan enkripsi): byte +17 lalu base64
#     Payload: patches/protected/<nama>.b64
#     Kuncinya ada di skrip ini, jadi siapa pun bisa membalikkannya.
# ------------------------------------------------------------------
# © 2026 @FebriCahyaa. All rights reserved.

PROTECT_SHIFT=17

protect_encode() {
    _src=$1
    _dst=$2
    [ -f "$_src" ] || return 1
    od -An -v -tu1 "$_src" 2>/dev/null \
        | awk -v s="$PROTECT_SHIFT" '{ for (i = 1; i <= NF; i++) printf "%c", ($i + s) % 256 }' \
        | base64 >"$_dst" 2>/dev/null
    return $?
}

protect_decode() {
    _src=$1
    _dst=$2
    [ -f "$_src" ] || return 1
    base64 -d "$_src" 2>/dev/null \
        | od -An -v -tu1 \
        | awk -v s="$PROTECT_SHIFT" '{ for (i = 1; i <= NF; i++) printf "%c", ($i - s + 256) % 256 }' \
        >"$_dst" 2>/dev/null
    return $?
}

native_decrypt() {
    _src=$1
    _dst=$2

    if [ "$A16FIXCTL" = none ] || [ ! -x "$A16FIXCTL" ]; then
        log E "USE_NATIVE_CRYPTO=1 tetapi a16fixctl tidak tersedia untuk ABI $DEVICE_ABI"
        return 1
    fi
    if [ ! -f "$NATIVE_KEYFILE" ]; then
        log E "keyfile tidak ada: $NATIVE_KEYFILE"
        return 1
    fi
    _mode=$(stat -c '%a' "$NATIVE_KEYFILE" 2>/dev/null || echo unknown)
    if [ "$_mode" != 600 ] && [ "$_mode" != 400 ]; then
        log W "keyfile sebaiknya 0600 (dapat: $_mode)"
    fi

    if "$A16FIXCTL" decrypt "$NATIVE_KEYFILE" "$_src" "$_dst" 2>>"$LOG_FILE"; then
        return 0
    fi
    log E "a16fixctl decrypt gagal (HMAC/padding tidak cocok)"
    rm -f "$_dst" 2>/dev/null || true
    return 1
}

# Muat patch: native AES > obfuscation > plaintext.
load_patch() {
    _name=$1
    _dst="$RUNTIME_DIR/patch_$_name.sh"

    if [ "$USE_NATIVE_CRYPTO" = 1 ] && [ -f "$MODDIR/patches/protected/$_name.enc" ]; then
        if native_decrypt "$MODDIR/patches/protected/$_name.enc" "$_dst"; then
            chmod 0600 "$_dst" 2>/dev/null || true
            log I "memuat patch AES terenkripsi: $_name"
            . "$_dst"
        else
            log E "patch $_name DITOLAK (dekripsi gagal)"
        fi
    elif [ "$USE_PROTECTED_PATCH" = 1 ] && [ -f "$MODDIR/patches/protected/$_name.b64" ]; then
        if protect_decode "$MODDIR/patches/protected/$_name.b64" "$_dst"; then
            chmod 0600 "$_dst" 2>/dev/null || true
            log I "memuat patch terproteksi (obfuscation): $_name"
            . "$_dst"
        else
            log E "gagal decode patch terproteksi: $_name"
        fi
    elif [ -f "$MODDIR/patches/$_name.sh" ]; then
        log I "memuat patch plaintext: $_name"
        . "$MODDIR/patches/$_name.sh"
    else
        log I "tidak ada patch $_name"
    fi
    return 0
}
