#!/system/bin/sh
# a16_data_fix :: deteksi Zygisk & metamodule

detect_zygisk() {
    ZYGISK_STATUS=unavailable
    ZYGISK_IMPL=none

    _bridge=$(gp ro.dalvik.vm.native.bridge)

    if [ "$ZYGISK_ENABLED" = 1 ]; then
        ZYGISK_STATUS=enabled
        ZYGISK_IMPL=magisk_builtin
    elif [ -d /data/adb/modules/zygisksu ]; then
        ZYGISK_STATUS=enabled
        ZYGISK_IMPL=zygisksu
    elif [ -d /data/adb/modules/ReZygisk ] || [ -d /data/adb/modules/ReZygisk_Next ]; then
        ZYGISK_STATUS=enabled
        ZYGISK_IMPL=rezgisk
    elif [ -d /data/adb/modules/neozgisk ] || [ -d /data/adb/modules/neozygisk ]; then
        ZYGISK_STATUS=enabled
        ZYGISK_IMPL=neozgisk
    elif printf '%s' "$_bridge" | grep -qi zygisk 2>/dev/null; then
        ZYGISK_STATUS=enabled
        ZYGISK_IMPL=native_bridge
    fi

    if [ "$ZYGISK_STATUS" = enabled ]; then
        : >"$RUNTIME_DIR/zygisk.ready" 2>/dev/null || true
    else
        rm -f "$RUNTIME_DIR/zygisk.ready" 2>/dev/null || true
    fi
    return 0
}

detect_metamodule() {
    METAMODULE_ACTIVE=0
    METAMODULE_ID=none

    if [ -L /data/adb/metamodule ]; then
        METAMODULE_ACTIVE=1
        METAMODULE_ID=$(basename "$(readlink /data/adb/metamodule 2>/dev/null)" 2>/dev/null)
        [ -n "$METAMODULE_ID" ] || METAMODULE_ID=linked
    fi

    for _id in hybrid_mount meta-overlayfs meta-overlay mountify meta-mm meta_magic_mount nomount zeromount; do
        if [ -d "/data/adb/modules/$_id" ]; then
            METAMODULE_ACTIVE=1
            [ "$METAMODULE_ID" = none ] && METAMODULE_ID=$_id
        fi
    done

    # Modul ini sengaja BUKAN metamodule. KSU hanya menerima satu metamodule,
    # dan metamodule butuh metamount.sh. Menandai modul ini sebagai metamodule
    # akan merusak mounting modul lain.
    IS_METAMODULE=0
    return 0
}
