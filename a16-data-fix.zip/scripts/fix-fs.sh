#!/system/bin/sh
# a16_data_fix :: penanganan filesystem F2FS / EXT4

fix_fs() {
    log I "fix-fs: mulai (fstype=$DATA_FSTYPE opts=$DATA_OPTS)"

    if [ "$FIX_FS" != 1 ]; then
        log I "fix-fs: dimatikan oleh config"
        return 0
    fi

    case "$DATA_FSTYPE" in
        f2fs | ext4)
            log I "filesystem /data dikenali: $DATA_FSTYPE"
            ;;
        unknown)
            log E "tidak bisa membaca fstype /data dari /proc/mounts"
            ;;
        *)
            log W "fstype /data tidak lazim: $DATA_FSTYPE (perlu diteliti)"
            ;;
    esac

    if [ "$FS_REMOUNT_NOATIME" = 1 ]; then
        if [ "$DATA_OPTS" = unknown ]; then
            log E "tidak bisa remount: opsi /data tidak diketahui"
        else
            case ",$DATA_OPTS," in
                *,noatime,*)
                    log I "noatime sudah aktif"
                    ;;
                *)
                    log W "mencoba remount /data dengan noatime"
                    if mount -o "remount,$DATA_OPTS,noatime" /data 2>/dev/null; then
                        log I "remount noatime berhasil"
                        DATA_OPTS=$(awk '$2 == "/data" { print $4; exit }' /proc/mounts 2>/dev/null)
                    else
                        log E "remount noatime GAGAL - opsi diabaikan"
                    fi
                    ;;
            esac
        fi
    fi

    if [ "$USE_CUSTOM_PATCH_FS" = 1 ]; then
        load_patch fs
    fi

    log I "fix-fs: selesai"
    return 0
}
