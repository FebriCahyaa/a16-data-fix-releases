#!/system/bin/sh
# a16_data_fix :: helper bersama
# Dipakai oleh semua skrip modul. Jangan dijalankan langsung.

MODDIR=${MODDIR:-${0%/*}}
RUNTIME_DIR=/data/adb/a16_data_fix
LOG_FILE=$RUNTIME_DIR/module.log
STATE_FILE=$RUNTIME_DIR/state.env
CONFIG_FILE=$RUNTIME_DIR/config.sh
LOG_MAX_BYTES=262144
STAGE=${STAGE:-unknown}
VERBOSE=${VERBOSE:-0}

mkdir -p "$RUNTIME_DIR" 2>/dev/null || true

_ts() { date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'unknown'; }

log() {
    _level=$1
    shift
    printf '%s [%-4s] %s\n' "$(_ts)" "$_level" "$*" >>"$LOG_FILE" 2>/dev/null
    if [ "$VERBOSE" = 1 ]; then
        printf '[%-4s] %s\n' "$_level" "$*" 2>/dev/null
    fi
    return 0
}

rotate_log() {
    [ -f "$LOG_FILE" ] || return 0
    _size=$(wc -c <"$LOG_FILE" 2>/dev/null | tr -d '[:space:]')
    case "$_size" in '' | *[!0-9]*) return 0 ;; esac
    if [ "$_size" -gt "$LOG_MAX_BYTES" ]; then
        rm -f "$LOG_FILE.2" 2>/dev/null
        mv -f "$LOG_FILE.1" "$LOG_FILE.2" 2>/dev/null || true
        mv -f "$LOG_FILE" "$LOG_FILE.1" 2>/dev/null || true
        : >"$LOG_FILE" 2>/dev/null || true
    fi
    return 0
}

gp() { getprop "$1" 2>/dev/null | head -n 1; }

init_runtime() {
    mkdir -p "$RUNTIME_DIR" 2>/dev/null || true
    rotate_log
    return 0
}

# ---------------------------------------------------------------------------
# Deteksi lingkungan
# ---------------------------------------------------------------------------

detect_root() {
    ROOT_SOLUTION=unknown
    ROOT_VERSION=unknown
    MAGISKTMP=none

    if [ "$KSU" = true ]; then
        ROOT_SOLUTION=kernelsu
        ROOT_VERSION=${KSU_VERSION:-unknown}
        if [ "$ROOT_VERSION" = unknown ] && command -v ksud >/dev/null 2>&1; then
            ROOT_VERSION=$(ksud -V 2>/dev/null | head -n 1)
        fi
    elif [ "$APATCH" = true ]; then
        ROOT_SOLUTION=apatch
        if command -v apd >/dev/null 2>&1; then
            ROOT_VERSION=$(apd -V 2>/dev/null | head -n 1)
        fi
    elif command -v magisk >/dev/null 2>&1; then
        ROOT_SOLUTION=magisk
        ROOT_VERSION=$(magisk -v 2>/dev/null | head -n 1)
        [ -n "$ROOT_VERSION" ] || ROOT_VERSION=$(magisk -V 2>/dev/null | head -n 1)
    fi

    if command -v magisk >/dev/null 2>&1; then
        MAGISKTMP=$(magisk --path 2>/dev/null || echo none)
    fi
    return 0
}

build_channel_estimate() {
    # Estimasi kasar dari rilis + tanggal patch keamanan.
    # BUKAN nilai resmi sistem: Android tidak punya property "QPR ke-n".
    _rel=$1
    _sp=$2
    case "$_rel" in
        16)
            case "$_sp" in
                2025-11-* | 2025-12-*) printf '%s' 'A16 QPR1 (estimasi)' ;;
                2026-01-* | 2026-02-* | 2026-03-*) printf '%s' 'A16 QPR2 (estimasi)' ;;
                2026-04-* | 2026-05-* | 2026-06-*) printf '%s' 'A16 QPR3 (estimasi)' ;;
                *) printf '%s' 'A16 (channel tidak diketahui)' ;;
            esac
            ;;
        17)
            case "$_sp" in
                2026-06-* | 2026-07-* | 2026-08-* | 2026-09-* | 2026-10-* | 2026-11-*) printf '%s' 'A17 base (estimasi)' ;;
                2026-12-* | 2027-01-*) printf '%s' 'A17 QPR1 (estimasi)' ;;
                2027-02-* | 2027-03-*) printf '%s' 'A17 QPR2 (estimasi)' ;;
                2027-04-* | 2027-05-* | 2027-06-*) printf '%s' 'A17 QPR3 (estimasi)' ;;
                *) printf '%s' 'A17 (channel tidak diketahui)' ;;
            esac
            ;;
        *) printf '%s' 'unknown' ;;
    esac
}

detect_android() {
    ANDROID_RELEASE=$(gp ro.build.version.release)
    ANDROID_SDK=$(gp ro.build.version.sdk)
    ANDROID_PREVIEW_SDK=$(gp ro.build.version.preview_sdk)
    ANDROID_BUILD_ID=$(gp ro.build.id)
    ANDROID_INCREMENTAL=$(gp ro.build.version.incremental)
    ANDROID_SECURITY_PATCH=$(gp ro.build.version.security_patch)
    ANDROID_QPR=$(build_channel_estimate "$ANDROID_RELEASE" "$ANDROID_SECURITY_PATCH")

    ANDROID_IS_16_PLUS=0
    ANDROID_IS_17_PLUS=0
    case "$ANDROID_SDK" in
        '' | *[!0-9]*) ;;
        *)
            if [ "$ANDROID_SDK" -ge 36 ]; then
                ANDROID_IS_16_PLUS=1
            fi
            if [ "$ANDROID_SDK" -ge 37 ]; then
                ANDROID_IS_17_PLUS=1
            fi
            ;;
    esac
    return 0
}

detect_kernel() {
    KERNEL_RELEASE=$(uname -r 2>/dev/null)
    KMI=$(printf '%s' "$KERNEL_RELEASE" | grep -o 'android[0-9][0-9]-[0-9]*' 2>/dev/null | head -n 1)
    [ -n "$KMI" ] || KMI=unknown
    return 0
}

detect_storage() {
    DATA_SOURCE=$(awk '$2 == "/data" { print $1; exit }' /proc/mounts 2>/dev/null)
    DATA_FSTYPE=$(awk '$2 == "/data" { print $3; exit }' /proc/mounts 2>/dev/null)
    DATA_OPTS=$(awk '$2 == "/data" { print $4; exit }' /proc/mounts 2>/dev/null)
    [ -n "$DATA_SOURCE" ] || DATA_SOURCE=unknown
    [ -n "$DATA_FSTYPE" ] || DATA_FSTYPE=unknown
    [ -n "$DATA_OPTS" ] || DATA_OPTS=unknown

    CRYPTO_STATE=$(gp ro.crypto.state)
    CRYPTO_TYPE=$(gp ro.crypto.type)
    return 0
}

detect_ril() {
    RILD_PRESENT=0
    for _svc in rild vendor.rild vendor.ril-daemon; do
        if [ -n "$(gp "init.svc.$_svc")" ]; then
            RILD_PRESENT=1
        fi
    done
    RIL_DEFAULT_NETWORK=$(gp ro.telephony.default_network)
    RIL_MULTISIM=$(gp persist.radio.multisim_config)
    RIL_SIM_STATE=$(gp gsm.sim.state)
    RIL_SLOTS=$(gp ro.telephony.sim.slots)
    return 0
}

detect_native() {
    DEVICE_ABI=$(gp ro.product.cpu.abi)
    [ -n "$DEVICE_ABI" ] || DEVICE_ABI=$(uname -m 2>/dev/null)
    case "$DEVICE_ABI" in
        aarch64 | arm64) DEVICE_ABI=arm64-v8a ;;
        i686 | i386) DEVICE_ABI=x86 ;;
    esac
    [ -n "$DEVICE_ABI" ] || DEVICE_ABI=unknown

    A16FIXCTL=none
    if [ -x "$MODDIR/bin/$DEVICE_ABI/a16fixctl" ]; then
        A16FIXCTL="$MODDIR/bin/$DEVICE_ABI/a16fixctl"
    fi

    ZYGISK_SO=0
    if [ -f "$MODDIR/zygisk/$DEVICE_ABI.so" ]; then
        ZYGISK_SO=1
    fi
    return 0
}

detect_environment() {
    detect_root
    detect_android
    detect_kernel
    detect_storage
    detect_ril
    detect_native
    return 0
}

save_state() {
    {
        printf "ROOT_SOLUTION='%s'\n" "$ROOT_SOLUTION"
        printf "ROOT_VERSION='%s'\n" "$ROOT_VERSION"
        printf "MAGISKTMP='%s'\n" "$MAGISKTMP"
        printf "ANDROID_RELEASE='%s'\n" "$ANDROID_RELEASE"
        printf "ANDROID_SDK='%s'\n" "$ANDROID_SDK"
        printf "ANDROID_IS_17_PLUS='%s'\n" "$ANDROID_IS_17_PLUS"
        printf "ANDROID_QPR='%s'\n" "$ANDROID_QPR"
        printf "ANDROID_SECURITY_PATCH='%s'\n" "$ANDROID_SECURITY_PATCH"
        printf "KERNEL_RELEASE='%s'\n" "$KERNEL_RELEASE"
        printf "KMI='%s'\n" "$KMI"
        printf "DATA_FSTYPE='%s'\n" "$DATA_FSTYPE"
        printf "DATA_OPTS='%s'\n" "$DATA_OPTS"
        printf "CRYPTO_STATE='%s'\n" "$CRYPTO_STATE"
        printf "CRYPTO_TYPE='%s'\n" "$CRYPTO_TYPE"
        printf "ZYGISK_STATUS='%s'\n" "$ZYGISK_STATUS"
        printf "ZYGISK_IMPL='%s'\n" "$ZYGISK_IMPL"
        printf "METAMODULE_ACTIVE='%s'\n" "$METAMODULE_ACTIVE"
        printf "METAMODULE_ID='%s'\n" "$METAMODULE_ID"
        printf "INTEGRITY_STATUS='%s'\n" "$INTEGRITY_STATUS"
        printf "INTEGRITY_ENGINE='%s'\n" "$INTEGRITY_ENGINE"
        printf "DEVICE_ABI='%s'\n" "$DEVICE_ABI"
        printf "A16FIXCTL='%s'\n" "$A16FIXCTL"
        printf "ZYGISK_SO='%s'\n" "$ZYGISK_SO"
    } >"$STATE_FILE" 2>/dev/null || true
    return 0
}

# ---------------------------------------------------------------------------
# Konfigurasi & property
# ---------------------------------------------------------------------------

load_config() {
    FIX_DATA_MOUNT=0
    FIX_RIL=0
    FIX_FS=0
    MOUNT_DATA_RW=1
    ENSURE_DATA_DIRS=1
    INJECT_PROPS=0
    RESTART_RILD=0
    FS_REMOUNT_NOATIME=0
    USE_CUSTOM_PATCH_DATA=0
    USE_CUSTOM_PATCH_RIL=0
    USE_CUSTOM_PATCH_FS=0
    REQUIRE_SHA256=1
    USE_PROTECTED_PATCH=0
    ZYGISK_REQUIRED=0
    ZYGISK_STATUS=unknown
    ZYGISK_IMPL=unknown
    METAMODULE_ACTIVE=0
    METAMODULE_ID=unknown
    IS_METAMODULE=0
    INTEGRITY_STATUS=unknown
    INTEGRITY_ENGINE=none
    USE_NATIVE_CRYPTO=0
    NATIVE_KEYFILE=/data/adb/a16_data_fix/keys/payload.key
    DEVICE_ABI=unknown
    A16FIXCTL=none
    ZYGISK_SO=0
    PREFERRED_NETWORK_MODE=
    CUSTOM_PROPS=

    if [ ! -f "$CONFIG_FILE" ]; then
        cp "$MODDIR/config/config.sh" "$CONFIG_FILE" 2>/dev/null || true
        chmod 600 "$CONFIG_FILE" 2>/dev/null || true
    fi
    if [ -f "$CONFIG_FILE" ]; then
        . "$CONFIG_FILE"
    fi
    return 0
}

rp() {
    _name=$1
    _value=$2
    [ -z "$_name" ] && return 0
    if command -v resetprop >/dev/null 2>&1; then
        if [ "$STAGE" = post_fs_data ]; then
            resetprop -n "$_name" "$_value" 2>/dev/null || true
        else
            resetprop "$_name" "$_value" 2>/dev/null || true
        fi
    else
        setprop "$_name" "$_value" 2>/dev/null || true
    fi
    return 0
}

_apply_prop_line() {
    _line=$1
    case "$_line" in '' | \#*) return 0 ;; esac
    _key=${_line%%=*}
    _val=${_line#*=}
    [ "$_key" = "$_line" ] && return 0
    rp "$_key" "$_val"
    log I "prop $_key=$_val"
    return 0
}

apply_custom_props() {
    [ "$INJECT_PROPS" = 1 ] || return 0
    if [ -f "$RUNTIME_DIR/props.list" ]; then
        while IFS= read -r _pl || [ -n "$_pl" ]; do
            _apply_prop_line "$_pl"
        done <"$RUNTIME_DIR/props.list"
    fi
    printf '%s\n' "$CUSTOM_PROPS" | while IFS= read -r _pl; do
        _apply_prop_line "$_pl"
    done
    return 0
}

# ---------------------------------------------------------------------------
# Laporan diagnostik
# ---------------------------------------------------------------------------

report() {
    printf '===== a16_data_fix :: diagnostic report =====\n'
    printf 'Copyright         : (c) 2026 @FebriCahyaa. All rights reserved.\n'
    printf 'Waktu             : %s\n' "$(_ts)"
    printf 'Root solution     : %s (%s)\n' "$ROOT_SOLUTION" "$ROOT_VERSION"
    printf 'Magisk tmp        : %s\n' "$MAGISKTMP"
    printf 'Android           : %s (SDK %s, preview %s)\n' "$ANDROID_RELEASE" "$ANDROID_SDK" "$ANDROID_PREVIEW_SDK"
    printf 'Build id          : %s / %s\n' "$ANDROID_BUILD_ID" "$ANDROID_INCREMENTAL"
    printf 'Security patch    : %s -> %s\n' "$ANDROID_SECURITY_PATCH" "$ANDROID_QPR"
    printf 'Android 16+ / 17+ : %s / %s\n' "$ANDROID_IS_16_PLUS" "$ANDROID_IS_17_PLUS"
    printf 'Kernel            : %s (KMI %s)\n' "$KERNEL_RELEASE" "$KMI"
    printf '/data source      : %s\n' "$DATA_SOURCE"
    printf '/data fstype      : %s\n' "$DATA_FSTYPE"
    printf '/data options     : %s\n' "$DATA_OPTS"
    printf 'Encryption        : state=%s type=%s\n' "$CRYPTO_STATE" "$CRYPTO_TYPE"
    printf 'RIL present       : %s\n' "$RILD_PRESENT"
    printf 'RIL network       : %s\n' "$RIL_DEFAULT_NETWORK"
    printf 'RIL multisim      : %s (slots %s)\n' "$RIL_MULTISIM" "$RIL_SLOTS"
    printf 'RIL sim state     : %s\n' "$RIL_SIM_STATE"
    printf 'Zygisk            : %s (%s)\n' "$ZYGISK_STATUS" "$ZYGISK_IMPL"
    printf 'Metamodule        : active=%s id=%s (modul ini BUKAN metamodule=%s)\n' "$METAMODULE_ACTIVE" "$METAMODULE_ID" "$IS_METAMODULE"
    printf 'Integritas SHA256 : %s (engine %s)\n' "$INTEGRITY_STATUS" "$INTEGRITY_ENGINE"
    printf 'ABI / native      : %s / a16fixctl=%s zygisk.so=%s\n' "$DEVICE_ABI" "$A16FIXCTL" "$ZYGISK_SO"
    printf 'Toggle            : mount=%s ril=%s fs=%s props=%s\n' "$FIX_DATA_MOUNT" "$FIX_RIL" "$FIX_FS" "$INJECT_PROPS"
    printf 'Config file       : %s\n' "$CONFIG_FILE"
    printf 'Log file          : %s\n' "$LOG_FILE"
    printf '==============================================\n'
}
