#!/system/bin/sh
# a16_data_fix :: verifikasi integritas SHA256
# Manifest dibuat oleh build.sh dari seluruh file modul yang dikirim.
# Memakai a16fixctl (native) bila tersedia, fallback ke sha256sum.

verify_integrity() {
    INTEGRITY_STATUS=unknown
    INTEGRITY_DETAIL=
    INTEGRITY_ENGINE=none

    if [ "$REQUIRE_SHA256" != 1 ]; then
        INTEGRITY_STATUS=skipped
        log I "verifikasi SHA256 dimatikan oleh config"
        return 0
    fi

    _manifest="$MODDIR/security/sha256.manifest"
    if [ ! -f "$_manifest" ]; then
        INTEGRITY_STATUS=missing
        log E "manifest SHA256 tidak ada - patch kustom DITOLAK"
        return 1
    fi

    _out="$RUNTIME_DIR/.verify.out"
    rm -f "$_out" 2>/dev/null || true

    # --- 1. Engine native (a16fixctl) -----------------------------------------
    _native=0
    if [ "$A16FIXCTL" != none ] && [ -x "$A16FIXCTL" ]; then
        if "$A16FIXCTL" sha256 "$MODDIR/module.prop" >/dev/null 2>&1; then
            _native=1
        fi
    fi

    if [ "$_native" = 1 ]; then
        INTEGRITY_ENGINE=a16fixctl
        "$A16FIXCTL" verify "$_manifest" "$MODDIR" >"$_out" 2>&1
        _rc=$?
        INTEGRITY_DETAIL=$(grep -v '^OK ' "$_out" 2>/dev/null | head -n 3)
        rm -f "$_out" 2>/dev/null || true
        if [ "$_rc" -eq 0 ]; then
            INTEGRITY_STATUS=ok
            log I "integritas SHA256 OK via a16fixctl ($(wc -l <"$_manifest" | tr -d ' ') file)"
            return 0
        fi
        INTEGRITY_STATUS=fail
        log E "integritas SHA256 GAGAL via a16fixctl - patch kustom DITOLAK"
        [ -n "$INTEGRITY_DETAIL" ] && log E "detail: $INTEGRITY_DETAIL"
        return 1
    fi

    # --- 2. Fallback sha256sum -------------------------------------------------
    if ! command -v sha256sum >/dev/null 2>&1; then
        INTEGRITY_STATUS=unsupported
        log W "a16fixctl dan sha256sum tidak tersedia - verifikasi dilewati"
        return 0
    fi

    INTEGRITY_ENGINE=sha256sum
    _res=$(cd "$MODDIR" && sha256sum -c security/sha256.manifest 2>&1)
    if [ $? -eq 0 ]; then
        INTEGRITY_STATUS=ok
        log I "integritas SHA256 OK via sha256sum ($(wc -l <"$_manifest" | tr -d ' ') file)"
        return 0
    fi

    INTEGRITY_STATUS=fail
    INTEGRITY_DETAIL=$(printf '%s\n' "$_res" | grep -v ': OK$' 2>/dev/null | head -n 3)
    log E "integritas SHA256 GAGAL - patch kustom DITOLAK"
    [ -n "$INTEGRITY_DETAIL" ] && log E "detail: $INTEGRITY_DETAIL"
    return 1
}
